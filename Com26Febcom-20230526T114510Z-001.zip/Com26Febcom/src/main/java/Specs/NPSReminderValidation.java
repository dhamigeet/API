package Specs;

import CRMHelper.NPSReminder;
import CRMHelper.helper;
import io.restassured.response.Response;
import org.testng.annotations.Test;

public class NPSReminderValidation extends helper {

    @Test(dataProvider="NPSReminderValidation")
    public void NPSReminderValidation(String case_number, String email ) {
        
        NPSReminder reminder = new NPSReminder ();
        Response response = reminder.NPSReminderFunc (case_number, email);
        response.body ().prettyPrint ();
  


    }
}
