package Specs;

import CRMHelper.CRMValidation;
import org.testng.annotations.Test;
import static org.testng.Assert.assertEquals;


public class VelocityPortal extends CRMValidation {


   @Test(dataProvider="VelocityPortal")
    public void SpecsValidation(String partnerId, String requestTimestamp , String code, String description) {
       CRMValidation crm = new CRMValidation();
       crm.VelocityPortalEnquiry (partnerId, requestTimestamp);
   
       assertEquals(crm.code, code);
       assertEquals(crm.description, description);
       }
}

