package Specs;

import CRMHelper.OnboardingCustomerValidation;
import CRMHelper.helper;
import io.restassured.response.Response;
import org.testng.annotations.Test;

public class OnboardingCustomerCreation extends helper {


    @Test(dataProvider="OnboardingCustomerCreationSheet")
    public void OnboardingCustomerCreationSheet(String mobile,String pan, String aadharRef, String accountType, String customerName,
                                                String middleName, String lastName, String panStatus, String nameMatchStatus,
                                                String blackListStatus, String contentId, String channel, String PfirstName,
                                                String PMiddleName, String PlastName, String requestId, String pfirstName,
                                                String pmiddleName, String plastName ){
        OnboardingCustomerValidation onboarding = new OnboardingCustomerValidation ();
        Response response = onboarding.OnboardingCustomerFunc (mobile, pan, aadharRef, accountType, customerName, middleName, lastName,
                panStatus, nameMatchStatus, blackListStatus, contentId, channel, PfirstName, PMiddleName, PlastName,
                requestId, pfirstName, pmiddleName, plastName );
        response.body ().prettyPrint ();

        }
        }


