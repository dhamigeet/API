package Specs.UPI;


import CRMHelper.UPIServices;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;

public class EnableUPI extends UPIServices {

    private String UpiService = "enable";


    @Test(dataProvider = "UPIServices")
    public void EnableUPI(String mcode, String mdescription, String mstatus) {


        UPIServices services = new UPIServices ();
        Response response = services.UPIServicesFunc (UpiService);
        String code = String.valueOf (response.path ("meta.code"));
        String status = String.valueOf (response.path ("meta.status"));
        String description = String.valueOf (response.path ("meta.description"));
        assertEquals (code, mcode);
        assertEquals (status, mstatus);
        assertEquals (description, mdescription);


    }
}
