package Specs.UPI;

import CRMHelper.SurveyValidation;
import CRMHelper.UPIServices;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;

public class DisableUPI extends UPIServices{


   private  String UpiService = "disable";


    @Test(dataProvider="UPIServices")
    public void DisableUPI(String mcode, String mdescription, String mstatus ) {


        UPIServices services = new UPIServices();
        Response response = services.UPIServicesFunc(UpiService);


        String code = String.valueOf (response.path("meta.code"));
        String status = String.valueOf (response.path("meta.status"));
        String description = String.valueOf (response.path("meta.description"));
        assertEquals(code,mcode );
        assertEquals(status,mstatus );
        assertEquals(description,mdescription );






    }

}
