package Specs;

import CRMHelper.helper;
import io.restassured.response.Response;
import org.testng.annotations.Test;
import static org.testng.Assert.assertEquals;



public class PANUpdate extends helper {

    String code;
    String description;
    String status;

    @Test
    public void PANUpdate() {

        Response response = getPANUpdateResponse (generatePANUpdateUrl ());
        response.body ().prettyPrint ();
        this.code = String.valueOf(response.path("meta.code"));
        this.description = response.path("meta.description");
        this.status = String.valueOf(response.path("meta.status"));
 
        assertEquals(this.code,code);
        assertEquals(this.description,description);
        assertEquals(this.status,status);
    }
}
