package Specs;

import CRMHelper.CRMValidation;
import CRMHelper.SurveyValidation;
import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;


public class NPSSurveyLink extends CRMValidation {



    @Test(dataProvider="SurveyLink")
    public void SurveyInsertionValidation(String rating, String feedback_text, String id, String answer, String code, String Statuses, String description ) {
        SurveyValidation SurevyIns = new SurveyValidation();
        SurevyIns.SurveyInsertion (rating,feedback_text, id , answer  );
        assertEquals(SurevyIns.code, code);
        assertEquals(SurevyIns.status, Statuses);
        assertEquals(SurevyIns.description, description);
        }
}


