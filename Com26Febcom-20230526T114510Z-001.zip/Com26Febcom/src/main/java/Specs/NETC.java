package Specs;

import CRMHelper.NETCServices;
import io.restassured.response.Response;

public class NETC  extends  NETCServices{

    @Override
    public Response NETCServicesm() {
        return super.NETCServicesm ();
    }
}