package Specs;

import CRMHelper.RetailerTV;
import CRMHelper.helper;
import io.restassured.response.Response;
import org.testng.annotations.Test;

public class RetailerTVValidation extends helper {

    String Status = "200";
    String message = "Record inserted succesfully";



    @Test(dataProvider="RetailerTV")
    public void RetailerTvValidation(String ret_lapu_number_c,String ret_alternate_mobile_number_c ,String dob,String OnboardingDate,
                                     String addressLine1,String addressLine2,String addressLine3,String addressline4,String shopAddress1,
                                     String shopAddress2,String shopAddress3,String shopAddress4,
                                     String circle, String advisorId,String advisorName, String firstName,String MName,String LastName ) {
        RetailerTV retv = new RetailerTV ();

        Response response = retv.RetailerTVFunc (ret_lapu_number_c,ret_alternate_mobile_number_c ,dob,OnboardingDate,
                addressLine1,addressLine2,addressLine3,addressline4,shopAddress1,shopAddress2,shopAddress3,shopAddress4,
                circle, advisorId,advisorName, firstName,MName,LastName);
        response.body ().prettyPrint ();

     






    }


}
