package Specs;

public interface CRMHelper {

}
