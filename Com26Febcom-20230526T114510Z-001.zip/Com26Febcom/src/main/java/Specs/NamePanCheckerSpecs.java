package Specs;

import CRMHelper.NAMEPANChecker;
import CRMHelper.SurveyValidation;
import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;

public class NamePanCheckerSpecs extends NAMEPANChecker {

    private String sessionId = "";
    private String contentId = "";
    private String custMsisdn = "";
    private String custType = "";
    private String custFname = "";
    private String custMname = "";
    private String custLname = "";
    private String panFname = "";
    private String panMname = "";
    private String panLname = "";
    private String circle = "";
    private String custDob = "";
    private String aadhaarRefId = "";
    private String pan = "";
    private String panCheckStatus = "";
    private String nameMatchCheckStatus = "";

    @Test(dataProvider = "NamePANChecker")
    public void NamePANCheckerValidation(String sessionId, String contentId, String custMsisdn, String custType, String custFname,
                                         String custMname, String custLname, String panFname, String panMname, String panLname,
                                         String circle, String custDob, String aadhaarRefId, String pan, String panCheckStatus, String nameMatchCheckStatus) {
       this.sessionId = sessionId;
       this.contentId = contentId;
       this.custMsisdn = custMsisdn;
       this.custType = custType;
        this.custFname = custFname;
        this.custMname = custMname;
        this.custLname = custLname;
        this.panFname = panFname;
        this.panMname = panMname;
        this.panLname = panLname;
        this.circle = circle;
        this.custDob = custDob;
        this.aadhaarRefId = aadhaarRefId;
        this.pan = pan;
        this.panCheckStatus = panCheckStatus;
        this.nameMatchCheckStatus = nameMatchCheckStatus;


    System.out.println("The Values are "+ this.sessionId+ " Content id is "+ contentId ) ;
    NAMEPANChecker checker = new NAMEPANChecker();
    checker.NamePANCheckerValidation(sessionId,contentId,custMsisdn,custType,custFname,custMname,custLname,panFname,panMname,
            panLname,circle,custDob,aadhaarRefId, pan, panCheckStatus, nameMatchCheckStatus );


    }
}