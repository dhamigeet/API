package Specs;

import CRMHelper.LendingKartLeads;
import CRMHelper.helper;
import io.restassured.response.Response;
import org.testng.annotations.Test;

public class LeadsModuleValidation extends helper {

    @Test(dataProvider="LendingKart")
    public void lendingValidation(String Id ) {
        LendingKartLeads kart = new LendingKartLeads ();
        Response response = kart.LendingKartLeadsFunc (Id);
        response.body ().prettyPrint ();
       

    }
}
