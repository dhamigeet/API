package Specs;

import CRMHelper.PromoterCaseCreation;
import io.restassured.response.Response;
import org.testng.annotations.Test;
import CRMHelper.helper;

public class PromoterCaseCreationSpecs extends helper {

    @Test(dataProvider = "PromoterCaseCreationSheet")
    public void PromoterCaseCreationSpecsFunc(String Mobile_Number, String actor_type, String description, String issue) {
        PromoterCaseCreation caseCreation = new PromoterCaseCreation ();
        Response response = caseCreation.PromoterCaseCreationFunc (Mobile_Number, actor_type, description, issue);
        }
}