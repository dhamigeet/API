package Specs;

import CRMHelper.AOPMakerValidation;
import CRMHelper.helper;
import io.restassured.response.Response;
import org.testng.annotations.Test;

public class AOPMakerSpecs extends helper {


        @Test(dataProvider="AOPMakerSheet")
        public void AOPMaker(String Custname, String mobile, String AddressLine1, String AddressLine2, String AddressLine3,
                             String AddressLine4, String State, String city, String Zip, String accountNumber, String activationDate,
                             String DOB, String POA ) {
            AOPMakerValidation aop = new AOPMakerValidation ();
            Response response = aop.AOPMakerfunc ( Custname, mobile, AddressLine1, AddressLine2, AddressLine3,
                    AddressLine4, State, city, Zip, accountNumber, activationDate,
                    DOB, POA);
            response.body ().prettyPrint ();
           
        }

    }
