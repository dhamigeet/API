package CRMHelper;

import io.restassured.response.Response;
import io.restassured.response.ResponseBody;

public class AOPMakerValidation extends helper {

    public Response AOPMakerfunc  (String Custname, String mobile, String AddressLine1, String AddressLine2, String AddressLine3,
                               String AddressLine4, String State, String city, String Zip, String accountNumber, String activationDate,
                               String DOB, String POA){

        String myjson = generateAOPJSON (Custname, mobile,AddressLine1, AddressLine2, AddressLine3,AddressLine4, State,  city,  Zip,  accountNumber,  activationDate,
                 DOB,  POA);
        Response response = getResponseFromAPIUnencrypted(myjson, AOPMakerUrl, contentTypeJson);
        ResponseBody body = response.getBody();
        System.out.println(body.asString());
        return(response);
        }

}
