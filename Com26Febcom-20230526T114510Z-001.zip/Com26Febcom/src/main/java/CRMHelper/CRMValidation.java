package CRMHelper;

import io.restassured.response.Response;

public class CRMValidation extends helper{

    public String description = "";
    public String code = "";

    public void VelocityPortalEnquiry(String partnerId,String requestTimestamp ) {
        String myjson = generateVelocityEnquiryJSON(partnerId, requestTimestamp);
        Response response = getResponseFromAPIUnencrypted( myjson, velocityPortalURL, contentTypeJson);
        response.body().prettyPrint ();
        this.code = response.path("meta.code");
        this.description = response.path("meta.description");

        }
}
