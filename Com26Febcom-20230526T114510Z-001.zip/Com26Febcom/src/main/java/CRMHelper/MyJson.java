package CRMHelper;

public class MyJson {

    String partnerId;
    String requestTimestamp;
    String rating;
    String feedback_text;
    String id;
    String answer;
    UPIServices questionaire;
    String sessionId;
    String contentId;
    String custMsisdn;
    String custType;
    String custFname;
    String custMname;
    String custLname;
    String panFname;
    String panMname;
    String circle;
    String custDob;
    String aadhaarRefId;
    String pan;
    String panCheckStatus;
    String nameMatchCheckStatus;
    String ret_lapu_number_c;
    String ret_alternate_mobile_number_c;
    String ret_dob_c;
    String ret_onboarding_date_c;
    String ret_address_line_1_c;
    String ret_address_line_2_c;
    String ret_address_line_3_c;
    String ret_address_line_4_c;
    String ret_shop_address_line_1_c;
    String ret_shop_address_line_2_c;
    String ret_shop_address_line_3_c;
    String ret_shop_address_line_4_c;
    String ret_circle_c;
    String ret_advisor_pbx_id_c;
    String ret_advisor_name_c;
    String ret_first_name_c;
    String ret_middle_name_c;
    String ret_last_name_c;
    String case_number ;
    String email;
    String cust_name;
    String mobile;
    String address_line_1;
    String address_line_2;
    String address_line_3;
    String address_line_4;
    String state;
    String city;
    String zip;
    String account_number;
    String Activation_date;
    String DOB;
    String POA;
    String mobile_number;
    String actor_type;
    String description;
    String issue;
    String aadharRef;
    String accountType;
    String customerName;
    String middleName;
    String lastName;
    String requestState;
    String panStatus;
    String nameMatchStatus;
    String blackListStatus;
    //String contentId;
    String channel;
    String pname;
    String firstName;
    //String middleName;
    String requestId;
    String pName;
    //String firstName;
   // String middleName;
   // String lastName;
    


    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public void setAadharRef(String aadharRef) {
        this.aadharRef = aadharRef;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setRequestState(String requestState) {
        this.requestState = requestState;
    }

    public void setPanStatus(String panStatus) {
        this.panStatus = panStatus;
    }

    public void setNameMatchStatus(String nameMatchStatus) {
        this.nameMatchStatus = nameMatchStatus;
    }

    public void setBlackListStatus(String blackListStatus) {
        this.blackListStatus = blackListStatus;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setpName(String pName) {
        this.pName = pName;
    }

    public void setCust_name(String cust_name) {
        this.cust_name = cust_name;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setAddress_line_1(String address_line_1) {
        this.address_line_1 = address_line_1;
    }

    public void setAddress_line_2(String address_line_2) {
        this.address_line_2 = address_line_2;
    }

    public void setAddress_line_3(String address_line_3) {
        this.address_line_3 = address_line_3;
    }

    public void setAddress_line_4(String address_line_4) {
        this.address_line_4 = address_line_4;
    }

    public void setState(String state) {
        this.state = state;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public void setAccount_number(String account_number) {
        this.account_number = account_number;
    }

    public void setActivation_date(String activation_date) {
        Activation_date = activation_date;
    }

    public void setDOB(String DOB) {
        this.DOB = DOB;
    }

    public void setPOA(String POA) {
        this.POA = POA;
    }

    public void setCase_number(String case_number) {
        this.case_number = case_number;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPartnerId() {
        return partnerId;
    }

    public String getRequestTimestamp() {
        return requestTimestamp;
    }

    public void setPartnerId(String partnerId) {
        this.partnerId = partnerId;
    }

    public void setRequestTimestamp(String requestTimestamp) {
        this.requestTimestamp = requestTimestamp;
    }

    public String getRating() {
        return rating;
    }

    public String getFeedback_text() {
        return feedback_text;
    }

    public String getId() {
        return id;
    }

    public String getAnswer() {
        return answer;
    }

    public UPIServices getQuestionaire() {
        return questionaire;
    }

    public String getSessionId() {
        return sessionId;
    }

    public String getContentId() {
        return contentId;
    }

    public String getCustMsisdn() {
        return custMsisdn;
    }

    public String getCustType() {
        return custType;
    }

    public String getCustFname() {
        return custFname;
    }

    public String getCustMname() {
        return custMname;
    }

    public String getCustLname() {
        return custLname;
    }

    public String getPanFname() {
        return panFname;
    }

    public String getPanMname() {
        return panMname;
    }

    public String getCircle() {
        return circle;
    }

    public String getCustDob() {
        return custDob;
    }

    public String getAadhaarRefId() {
        return aadhaarRefId;
    }

    public String getPan() {
        return pan;
    }

    public String getPanCheckStatus() {
        return panCheckStatus;
    }

    public String getNameMatchCheckStatus() {
        return nameMatchCheckStatus;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public void setFeedback_text(String feedback_text) {
        this.feedback_text = feedback_text;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }


    public void setQuestionaire(UPIServices questionaire) {

        this.questionaire = questionaire;

    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public void setContentId(String contentId) {
        this.contentId = contentId;
    }

    public void setCustMsisdn(String custMsisdn) {
        this.custMsisdn = custMsisdn;
    }

    public void setCustType(String custType) {
        this.custType = custType;
    }

    public void setCustFname(String custFname) {
        this.custFname = custFname;
    }

    public void setCustMname(String custMname) {
        this.custMname = custMname;
    }

    public void setCustLname(String custLname) {
        this.custLname = custLname;
    }

    public void setPanFname(String panFname) {
        this.panFname = panFname;
    }

    public void setPanMname(String panMname) {
        this.panMname = panMname;
    }

    public void setCircle(String circle) {
        this.circle = circle;
    }

    public void setCustDob(String custDob) {
        this.custDob = custDob;
    }

    public void setAadhaarRefId(String aadhaarRefId) {
        this.aadhaarRefId = aadhaarRefId;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public void setPanCheckStatus(String panCheckStatus) {
        this.panCheckStatus = panCheckStatus;
    }

    public void setNameMatchCheckStatus(String nameMatchCheckStatus) {
        this.nameMatchCheckStatus = nameMatchCheckStatus;
    }


    public String getRet_lapu_number_c() {
        return ret_lapu_number_c;
    }

    public String getRet_alternate_mobile_number_c() {
        return ret_alternate_mobile_number_c;
    }

    public String getRet_dob_c() {
        return ret_dob_c;
    }

    public String getRet_onboarding_date_c() {
        return ret_onboarding_date_c;
    }

    public String getRet_address_line_1_c() {
        return ret_address_line_1_c;
    }

    public String getRet_address_line_2_c() {
        return ret_address_line_2_c;
    }

    public String getRet_address_line_3_c() {
        return ret_address_line_3_c;
    }

    public String getRet_address_line_4_c() {
        return ret_address_line_4_c;
    }

    public String getRet_shop_address_line_1_c() {
        return ret_shop_address_line_1_c;
    }

    public String getRet_shop_address_line_2_c() {
        return ret_shop_address_line_2_c;
    }

    public String getRet_shop_address_line_3_c() {
        return ret_shop_address_line_3_c;
    }

    public String getRet_shop_address_line_4_c() {
        return ret_shop_address_line_4_c;
    }

    public String getRet_circle_c() {
        return ret_circle_c;
    }

    public String getRet_advisor_pbx_id_c() {
        return ret_advisor_pbx_id_c;
    }

    public String getRet_advisor_name_c() {
        return ret_advisor_name_c;
    }

    public String getRet_first_name_c() {
        return ret_first_name_c;
    }

    public String getRet_middle_name_c() {
        return ret_middle_name_c;
    }

    public String getRet_last_name_c() {
        return ret_last_name_c;
    }

    public void setRet_lapu_number_c(String ret_lapu_number_c) {
        this.ret_lapu_number_c = ret_lapu_number_c;
    }

    public void setRet_alternate_mobile_number_c(String ret_alternate_mobile_number_c) {
        this.ret_alternate_mobile_number_c = ret_alternate_mobile_number_c;
    }

    public void setRet_dob_c(String ret_dob_c) {
        this.ret_dob_c = ret_dob_c;
    }

    public void setRet_onboarding_date_c(String ret_onboarding_date_c) {
        this.ret_onboarding_date_c = ret_onboarding_date_c;
    }

    public void setRet_address_line_1_c(String ret_address_line_1_c) {
        this.ret_address_line_1_c = ret_address_line_1_c;
    }

    public void setRet_address_line_2_c(String ret_address_line_2_c) {
        this.ret_address_line_2_c = ret_address_line_2_c;
    }

    public void setRet_address_line_3_c(String ret_address_line_3_c) {
        this.ret_address_line_3_c = ret_address_line_3_c;
    }

    public void setRet_address_line_4_c(String ret_address_line_4_c) {
        this.ret_address_line_4_c = ret_address_line_4_c;
    }

    public void setRet_shop_address_line_1_c(String ret_shop_address_line_1_c) {
        this.ret_shop_address_line_1_c = ret_shop_address_line_1_c;
    }

    public void setRet_shop_address_line_2_c(String ret_shop_address_line_2_c) {
        this.ret_shop_address_line_2_c = ret_shop_address_line_2_c;
    }

    public void setRet_shop_address_line_3_c(String ret_shop_address_line_3_c) {
        this.ret_shop_address_line_3_c = ret_shop_address_line_3_c;
    }

    public void setRet_shop_address_line_4_c(String ret_shop_address_line_4_c) {
        this.ret_shop_address_line_4_c = ret_shop_address_line_4_c;
    }

    public void setRet_circle_c(String ret_circle_c) {
        this.ret_circle_c = ret_circle_c;
    }

    public void setRet_advisor_pbx_id_c(String ret_advisor_pbx_id_c) {
        this.ret_advisor_pbx_id_c = ret_advisor_pbx_id_c;
    }

    public void setRet_advisor_name_c(String ret_advisor_name_c) {
        this.ret_advisor_name_c = ret_advisor_name_c;
    }

    public void setRet_first_name_c(String ret_first_name_c) {
        this.ret_first_name_c = ret_first_name_c;
    }

    public void setRet_middle_name_c(String ret_middle_name_c) {
        this.ret_middle_name_c = ret_middle_name_c;
    }

    public void setRet_last_name_c(String ret_last_name_c) {
        this.ret_last_name_c = ret_last_name_c;
    }
    public void setMobile_number(String mobile_number) {
        this.mobile_number = mobile_number;
    }

    public void setActor_type(String actor_type) {
        this.actor_type = actor_type;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setIssue(String issue) {
        this.issue = issue;
    }


}
