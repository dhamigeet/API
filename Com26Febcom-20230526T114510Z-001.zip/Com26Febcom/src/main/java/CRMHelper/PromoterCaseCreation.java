package CRMHelper;

import io.restassured.response.Response;
import io.restassured.response.ResponseBody;

public class PromoterCaseCreation extends helper {

    public Response PromoterCaseCreationFunc(String Mobile_Number, String actor_type, String description, String issue){
        String myjson = generateCreateCase (Mobile_Number,actor_type,description, issue );
        Response response = getResponseFromAPIUnencrypted(myjson, CaseCreationUrl, contentTypeJson);
        ResponseBody body = response.getBody();
        return(response);

    }
}
