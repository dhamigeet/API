package CRMHelper;

import io.restassured.response.Response;
import io.restassured.response.ResponseBody;

public class OnboardingCustomerValidation extends helper{


    public Response OnboardingCustomerFunc(String mobile,String pan, String aadharRef, String accountType, String customerName,
                                           String middleName, String lastName, String panStatus, String nameMatchStatus,
                                           String blackListStatus, String contentId, String channel, String PfirstName,
                                           String PMiddleName, String PlastName, String requestId, String pfirstName,
                                           String pmiddleName, String plastName ) {
        String myjson = generateOnboardingCustomerCreationJSON (mobile, pan, aadharRef, accountType, customerName, middleName, lastName,
                panStatus, nameMatchStatus, blackListStatus, contentId, channel, PfirstName, PMiddleName, PlastName,
                requestId, pfirstName, pmiddleName, plastName);
        Response response = getResponseFromAPIUnencrypted (myjson, OnboardingcustomerCreationUrl, contentTypeJson);
        ResponseBody body = response.getBody ();
        return (response);


    }
}
