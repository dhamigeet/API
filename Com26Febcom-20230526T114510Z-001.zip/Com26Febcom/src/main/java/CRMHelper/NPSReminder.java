package CRMHelper;

import io.restassured.response.Response;
import io.restassured.response.ResponseBody;

public class NPSReminder  extends  helper{

    public Response NPSReminderFunc(String case_number, String email){
    String myjson = generateNPSReminderJSON(case_number,email );
    Response response = getResponseFromAPIUnencrypted(myjson, NPSReminderUrl, contentTypeJson);
    ResponseBody body = response.getBody();
    return(response);

    }

}
