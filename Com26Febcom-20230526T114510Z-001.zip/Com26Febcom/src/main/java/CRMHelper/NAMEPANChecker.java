package CRMHelper;

import io.restassured.response.Response;


public class NAMEPANChecker extends helper{

    public void NamePANCheckerValidation(String sessionId, String contentId, String custMsisdn, String custType, String custFname, String custMname, String custLname, String panFname,String panMname,String panLname, String circle, String custDob,String aadhaarRefId,String pan,String panCheckStatus,String nameMatchCheckStatus) {

        String myjson = generatePANNameCheckerJSON (sessionId, contentId, custMsisdn, custType, custFname, custMname, custLname, panFname, panMname, panLname, circle, custDob, aadhaarRefId, pan, panCheckStatus, nameMatchCheckStatus);


        Response response = getResponseFromAPIUnencryptedXml(myjson, NamePANpath, contentTypeJson);
        response.body().prettyPrint ();


    }

}
