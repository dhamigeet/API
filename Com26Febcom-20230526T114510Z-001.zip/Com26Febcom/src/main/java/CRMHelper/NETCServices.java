package CRMHelper;

import io.restassured.response.Response;
import io.restassured.response.ResponseBody;

public class NETCServices extends helper {


    public Response NETCServicesm(){

        Response response = getresponseFromNETC(NETCUrl);
        ResponseBody body = response.getBody();
        System.out.println(body.prettyPrint ());
        return(response);
    }
}
