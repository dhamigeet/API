package CRMHelper;

import com.google.gson.Gson;
import org.testng.annotations.DataProvider;

import java.io.IOException;

public abstract class helper extends GlobalHelper {

    public String configPath = "./src/main/java/Configs/Configuration.Properties";
    public String velocityPortalURL = readFromPropertiesFile (configPath, "velocityPortal.BASEURL");
    public String SurveyLinkURL = readFromPropertiesFile (configPath, "CRMSurveyUrl");
    public String CRMExcelPath = readFromPropertiesFile (configPath, "CRMExcelPath");
    public String PANUPdateURL = readFromPropertiesFile (configPath, "PANUpdateUrl");
    public String UPIUrl = readFromPropertiesFile (configPath, "UPIUrl");
    public String NETCUrl = readFromPropertiesFile (configPath, "NETCUrl");
    public String UPIURL = "";
    public String NamePANpath = readFromPropertiesFile (configPath, "NAMEPANChecker");
    public String VelocityPortalPath = readFromPropertiesFile (configPath, "RetailerTvUrl");
    public String LendingKartUrl = readFromPropertiesFile (configPath, "LendingKartUrl");
    public String NPSReminderUrl = readFromPropertiesFile (configPath, "NPSReminderUrl");
    public String AOPMakerUrl = readFromPropertiesFile (configPath, "AOPMaker");
    public String OnboardingcustomerCreationUrl = readFromPropertiesFile (configPath, "onboardingCustomerCreation");
    public String CaseCreationUrl = readFromPropertiesFile (configPath, "CaseCreation");

    public String generateVelocityEnquiryJSON(String partnerId, String requestTimestamp) {
        Gson gson = new Gson ();
        MyJson json = new MyJson ();
        json.setPartnerId (partnerId);
        json.setRequestTimestamp (requestTimestamp);
        return gson.toJson (json).toString ();
    }



    public String generateOnboardingCustomerCreationJSON(String mobile, String pan, String AadharRef, String accountType, String FirstName,
                                                         String MiddleName, String LastName, String PanStatus, String NatchStatus,
                                                         String BlacklistStatus, String ContentId, String Channel, String Firstname,
                                                         String middlename, String Lastname,String requestId, String pFirstName,
                                                         String pMiddleName, String pLastName
                                                         ) {
        Gson gson = new Gson ();
        MyJson json = new MyJson ();
       json.setMobile (mobile);
       json.setPan (pan);
       json.setAadharRef (AadharRef);
       json.setAccountType (accountType);
       json.setFirstName (FirstName);
       json.setMiddleName (MiddleName);
       json.setLastName (LastName);
       json.setPanStatus (PanStatus);
       json.setNameMatchStatus (NatchStatus);
       json.setBlackListStatus (BlacklistStatus);
       json.setContentId (ContentId);
       json.setChannel (Channel);
       json.setFirstName (Firstname);
       json.setMiddleName (middlename);
       json.setLastName (Lastname);
       json.setRequestId (requestId);
       json.setFirstName (pFirstName);
       json.setMiddleName (pMiddleName);
       json.setLastName (pLastName);
        return gson.toJson (json).toString ();
    }

    public String generateAOPJSON(String Custname, String mobile, String AddressLine1, String AddressLine2, String AddressLine3,
                                  String AddressLine4, String State, String city, String Zip, String accountNumber, String activationDate,
                                  String DOB, String POA) {
        Gson gson = new Gson ();
        MyJson json = new MyJson ();
        json.setCust_name (Custname);
        json.setMobile (mobile);
        json.setAddress_line_1 (AddressLine1);
        json.setAddress_line_2 (AddressLine2);
        json.setAddress_line_3 (AddressLine3);
       json.setAddress_line_4 (AddressLine4);
        json.setState (State);
        json.setCity (city);
        json.setZip (Zip);
        json.setAccount_number (accountNumber);
        json.setActivation_date (activationDate);
        json.setDOB (DOB);
        json.setPOA (POA);
        return gson.toJson (json).toString ();
    }


    public String generateRetailerTvJSON(String ret_lapu_number_c, String retAlternateMobileNumberC, String dob, String OnboardingDate, String addressLine1, String addressLine2, String addressLine3, String addressline4, String shopAddress1, String shopAddress2, String shopAddress3, String shopAddress4, String circle, String advisorId, String advisorName, String firstName, String MName,
                                         String LastName){

        Gson gson = new Gson ();
        MyJson json = new MyJson ();
        json.setRet_lapu_number_c (ret_lapu_number_c);
        json.setRet_alternate_mobile_number_c (retAlternateMobileNumberC);
        json.setRet_dob_c (dob);
        json.setRet_onboarding_date_c (OnboardingDate);
        json.setRet_address_line_1_c ( addressLine1);
        json.setRet_address_line_2_c (addressLine2);
        json.setRet_address_line_3_c (addressLine3);
        json.setRet_address_line_4_c (addressline4);
        json.setRet_shop_address_line_1_c  (shopAddress1);
        json.setRet_shop_address_line_2_c (shopAddress2);
        json.setRet_shop_address_line_3_c (shopAddress3);
        json.setRet_shop_address_line_4_c (shopAddress4);
        json.setRet_circle_c (circle);
        json.setRet_advisor_pbx_id_c (advisorId);
        json.setRet_advisor_name_c (advisorName);
        json.setRet_first_name_c (firstName);
        json.setRet_middle_name_c (MName);
        json.setRet_last_name_c (LastName);
        return gson.toJson(json).toString();
    }


    public String generateSurveyJSON(String rating, String feedback_text, String id , String answer ) {
        Gson gson = new Gson ();
        MyJson json = new MyJson ();
        UPIServices qr = new UPIServices ();
        json.setRating (rating);
        json.setFeedback_text (feedback_text);
        json.setQuestionaire (qr);
        //qr.setAnswer (answer);
       // qr.setId (id);
        return gson.toJson(json).toString();
    }

    public String generatePANNameCheckerJSON(String sessionId, String contentId, String custMsisdn, String custType, String custFname,
                                             String custMname,String custLname, String panFname, String panMname, String panLname,
                                             String circle, String custDob, String aadhaarRefId, String pan, String panCheckStatus,
                                             String nameMatchCheckStatus) {
        Gson gson = new Gson ();
        MyJson json = new MyJson ();
        json.setSessionId (sessionId);
        json.setContentId (contentId);
        json.setCustMsisdn (custMsisdn);
        json.setCustType (custType);
        json.setCustFname (custFname);
        json.setCustMsisdn (custMsisdn);
        json.setCustMname (custMname);
        json.setCustLname (custLname);
        json.setPanFname (panFname);
        json.setPanMname (panMname);
       // json.set (panLname);
        json.setCircle (circle);
        json.setCustDob (custDob);
        json.setAadhaarRefId (aadhaarRefId);
        json.setPan (pan);
        json.setPanCheckStatus(panCheckStatus);
        json.setNameMatchCheckStatus (nameMatchCheckStatus);
        return gson.toJson(json).toString();
    }


    public String generateLendingKartJSON(String id ) {
        Gson gson = new Gson ();
        MyJson json = new MyJson ();
        json.setId (id);
        return gson.toJson(json).toString();

    }


    public String generateCreateCase(String Mobile_number, String actor_type, String description, String issue ) {
        Gson gson = new Gson ();
        MyJson json = new MyJson ();
        json.setMobile_number (Mobile_number);
        json.setActor_type (actor_type);
        json.setDescription (description);
        json.setIssue (issue);
        return gson.toJson(json);

    }



    public String generateNPSReminderJSON(String Case, String email ) {
        Gson gson = new Gson ();
        MyJson json = new MyJson ();
        json.setCase_number (Case);
        json.setEmail (email);
        return gson.toJson(json).toString();

    }

    public String generateUrl(){
        String Surveylink = SurveyLinkURL+"crm_id="+generateRandomCaseNumber ()+"&date=2019-01-25";
        return Surveylink;
    }


    public String generatePANUpdateUrl(){
        String PANUrl = PANUPdateURL+generateRandomCaseNumber()+
                generateRandomMobileNumber ()+"/identities/pan/AAAPW"+
                generateRandomCaseNumber ()
                +generateRandomCaseNumber()+"W";
        return PANUrl;
    }


  public String generateUPIServices(String UPIServices ){
      UPIURL = UPIUrl+UPIServices+"/9821608646";
      return UPIURL;
      }






   @DataProvider
    public Object[][] VelocityPortal() throws IOException {
        String[][] data = readFromExcel( CRMExcelPath , "VelocityPortals");
        return data;
    }

    @DataProvider
    public Object[][] SurveyLink() throws IOException {
        String[][] data = readFromExcel( CRMExcelPath , "Surveylink");
        return data; }


    @DataProvider
    public Object[][] UPIServices() throws IOException {
        String[][] data = readFromExcel( CRMExcelPath , "UPIServices");
        return data; }


    @DataProvider
    public Object[][] PanUpdate() throws IOException {
        String[][] data = readFromExcel( CRMExcelPath , "PanUpdate");
        return data; }

    @DataProvider
    public Object[][] UPI() throws IOException {
        String[][] data = readFromExcel( CRMExcelPath , "UPI");
        return data; }

    @DataProvider
    public Object[][] NamePANChecker() throws IOException {
        String[][] data = readFromExcel( CRMExcelPath , "NamePANChecker");
        return data;
    }

    @DataProvider
    public Object[][] RetailerTV() throws IOException {
        String[][] data = readFromExcel( CRMExcelPath , "RetailerTV");
        return data;
    }


    @DataProvider
    public Object[][] LendingKart() throws IOException {
        String[][] data = readFromExcel( CRMExcelPath , "LendingKart");
        return data;
    }

    @DataProvider
    public Object[][] NPSReminderValidation() throws IOException {
        String[][] data = readFromExcel( CRMExcelPath , "NPSReminder");
        return data;
    }


    @DataProvider
    public Object[][] AOPMakerSheet() throws IOException {
        String[][] data = readFromExcel( CRMExcelPath , "AOPMAker");
        return data;
    }


    @DataProvider
    public Object[][] OnboardingCustomerCreationSheet() throws IOException {
        String[][] data = readFromExcel( CRMExcelPath , "OnboardingCustomerCreation");
        return data;
    }

    @DataProvider
    public Object[][] PromoterCaseCreationSheet() throws IOException {
        String[][] data = readFromExcel( CRMExcelPath , "PromoterCaseCreation");
        return data;
    }


}
