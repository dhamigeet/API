package CRMHelper;

import io.restassured.response.Response;
import io.restassured.response.ResponseBody;

public class UPIServices extends helper{


    public Response UPIServicesFunc(String upiService)
    {

        Response response = getUPIResponseFromAPIUnencrypted( generateUPIServices (upiService), contentTypeJson , UPiChannel);
        ResponseBody body = response.getBody();
        System.out.println(body.asString());
        return(response);

        }
}
