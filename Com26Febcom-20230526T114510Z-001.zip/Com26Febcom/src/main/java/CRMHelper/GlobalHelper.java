package CRMHelper;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.File;
import java.util.*;
import java.io.InputStream;
import static io.restassured.RestAssured.given;
import static java.util.concurrent.ThreadLocalRandom.*;

public class GlobalHelper {


    public String contentTypeJson = "application/json";
    public String contentTypeXml = "application/xml";
    public String contentId = "dhjeijnf";
    public String Channel = "RAPP";
    public String UPiChannel = "CRM";
    public String UPIChannelname= "channel";
    public String dbConfigPath = "./src/main/java/Configs/db.Properties";



    public Response getResponseFromAPIUnencrypted(String myjson, String url, String contentType) {
        System.out.println("--------------------REQUEST------------------");
        RestAssured.useRelaxedHTTPSValidation();
        Response response = given().contentType(contentType).body(myjson).log().all().when().post(url).then().extract()
                .response();
        System.out.println("----------------------RESPONSE------------------");
        return response;
    }


    public Response getResponseFromAPIUnencryptedXml(String myjson, String url, String contentTypeXml) {
        System.out.println("--------------------REQUEST------------------");
        RestAssured.useRelaxedHTTPSValidation();
        Response response = given().contentType(contentTypeXml).body(myjson).log().all().when().post(url).then().extract()
                .response();
        System.out.println("----------------------RESPONSE------------------");
        return response;
    }


    public Response getresponseFromNETC(String url) {
        System.out.println("--------------------REQUEST------------------");
        RestAssured.useRelaxedHTTPSValidation();
        Response response = given().header ("contentId", contentId).log().all().when().post(url).then().extract()
                .response();
        System.out.println("----------------------RESPONSE------------------");
        return response;
    }



    public Response getUPIResponseFromAPIUnencrypted(String url, String contentTypeJson, String channel) {
        System.out.println("--------------------REQUEST------------------");
        RestAssured.useRelaxedHTTPSValidation();
        Response response = given().contentType(contentTypeJson).header (UPIChannelname,channel).
                log().all().
                when().
                post(url).
                then().
                extract()
                .response();
        System.out.println("----------------------RESPONSE------------------");
        return response;
    }


    public Response getPANUpdateResponse(String url ){
        System.out.println("--------------------REQUEST------------------");
        Response response = (Response) given().
                log().all().
                and().
                header("contentId",("dhjeijnf")).
                header("channel","RAPP").
                when().
                get(url).
                then().
                extract();
        System.out.println("----------------------RESPONSE------------------");
        return response;

    }

    public Response getresponseFromRetailerTv(String url) {
        System.out.println("--------------------REQUEST------------------");

        Response response = given().header ("contentId", contentId).log().all().when().post(url).then().extract()
                .response();
        System.out.println("----------------------RESPONSE------------------");
        return response;
    }






    public String generateRandomCaseNumber() {
        String number = Integer.toString(current().nextInt(11, 99));
        return number;
    }


    public String generateRandomMobileNumber() {
        String number = Integer.toString(current().nextInt(10000000, 99999999));
        return number;
    }




    /** --------------------Reading Excel -------------------- */

    public static String[][] readFromExcel(String filePath, String sheetName) throws IOException {
        File file = new File(filePath);
        FileInputStream inputStream = new FileInputStream(file);
        XSSFWorkbook myWB = new XSSFWorkbook (inputStream);
        Sheet sheet = myWB.getSheet(sheetName);
        System.out.println("las row num: " + sheet.getLastRowNum());
        System.out.println("first row: " + sheet.getFirstRowNum());
        int rowCount = sheet.getLastRowNum() - sheet.getFirstRowNum();
        int colCount = sheet.getRow(0).getLastCellNum();
        String[][] excel = new String[rowCount][colCount];

        for (int i = 0; i < rowCount; i++) {
            org.apache.poi.ss.usermodel.Row row = sheet.getRow (i+1);

            for (int j = 0; j < row.getLastCellNum(); j++) {
                excel[i][j] = row.getCell(j).toString();
            }
        }
        myWB.close();
        return excel;
    }



    // Extent Manager reporting
    /** --------------------EXTENT REPORT CODE - START-------------------- */

    public static ExtentReports extent;
    public static ThreadLocal<ExtentTest> parentTest = new ThreadLocal<ExtentTest>();
    public static ThreadLocal<ExtentTest> testLog = new ThreadLocal<ExtentTest>();
    public Map<String, ExtentTest> map = new HashMap<String, ExtentTest> ();

    @BeforeSuite
    public void setup() {
        extent = ExtentManager.GetExtent();
    }


    @BeforeClass
    public void beforeClass() {
        String className = getClass().getName();
        className = className.substring(className.lastIndexOf(".") + 1);
        ExtentTest parent = extent.createTest(className);
        parentTest.set(parent);

    }

    @AfterMethod
    public void afterMethod() {
        extent.flush();
    }

    @AfterSuite
    public void cleanUp() {
        // cleanup code goes here
    }



    /** --------------------Reading property file-------------------- */
    public String readFromPropertiesFile(String fileName, String propertyName) {
        String propertyValue = null;
        Properties prop = new Properties();
        InputStream input = null;

        try {
            input = new FileInputStream(fileName);

            // load a properties file
            prop.load(input);

            // get the property value
            propertyValue = prop.getProperty(propertyName);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return propertyValue;
    }


}
