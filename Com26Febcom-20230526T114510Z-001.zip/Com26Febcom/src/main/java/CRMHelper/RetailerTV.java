package CRMHelper;

import io.restassured.response.Response;
import io.restassured.response.ResponseBody;

public class RetailerTV extends helper{


    public Response RetailerTVFunc(String ret_lapu_number_c, String ret_alternate_mobile_number_c, String dob, String onboardingDate, String addressLine1, String addressLine2, String addressLine3, String addressline4, String shopAddress1, String shopAddress2, String shopAddress3, String shopAddress4, String circle, String advisorId, String advisorName, String firstName, String MName, String lastName)
    {
        String myjson = generateRetailerTvJSON(ret_lapu_number_c,ret_alternate_mobile_number_c, dob,onboardingDate,
                addressLine1, addressLine2, addressLine3, addressline4, shopAddress1, shopAddress2, shopAddress3, shopAddress4,
                circle, advisorId,advisorName, firstName,MName,lastName );
        Response response = getResponseFromAPIUnencrypted(myjson, VelocityPortalPath, contentTypeJson);
        ResponseBody body = response.getBody();
        System.out.println(body.asString());
        return(response);

    }

}
