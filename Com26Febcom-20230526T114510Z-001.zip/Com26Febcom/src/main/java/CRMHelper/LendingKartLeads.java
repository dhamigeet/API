package CRMHelper;

import io.restassured.response.Response;
import io.restassured.response.ResponseBody;

public class LendingKartLeads extends helper{

    public Response LendingKartLeadsFunc(String id)
    {
        String myjson = generateLendingKartJSON(id);
        Response response = getResponseFromAPIUnencrypted(myjson, LendingKartUrl, contentTypeJson);
        ResponseBody body = response.getBody();
        System.out.println(body.asString());
        return(response);

    }


}
