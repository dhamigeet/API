package CRMHelper;

import io.restassured.response.Response;
import io.restassured.response.ResponseBody;

public class SurveyValidation extends helper {

    public String description = "";
    public String code = "";
    public String status = "";


    public void SurveyInsertion(String rating, String feedback_text, String id, String answer )
    {
        String myjson = generateSurveyJSON(rating, feedback_text,id,answer );
        Response response = getResponseFromAPIUnencrypted( myjson, generateUrl(), contentTypeJson);
        ResponseBody body = response.getBody();
        System.out.println(body.asString());
        this.code = String.valueOf (response.path("meta.code"));
        this.status = String.valueOf(response.path("meta.status"));
        this.description = response.path ("meta.description");


    }
}
