package upi.cucumber.tests;

import cucumber.api.CucumberOptions;

import com.github.mkolisnyk.cucumber.runner.ExtendedCucumberOptions;
import com.github.mkolisnyk.cucumber.runner.ExtendedTestNGRunner;

@ExtendedCucumberOptions(jsonReport = "com/results/cucumber-reports/cucumber.json", retryCount = 3, detailedReport = true, overviewReport = true, knownErrorsReport = true, detailedAggregatedReport = true, jsonUsageReport = "com/results/cucumber-reports/cucumber-usage.json", usageReport = true, toPDF = true, knownErrorsConfig = "com/upi/resources/known-errors-source/sample_model.json", outputFolder = "com/results")
@CucumberOptions(plugin = { "pretty", "html:com/results/cucumber-reports/cucumber-html-report",
		"json:com/results/cucumber-reports/cucumber.json", "usage:com/results/cucumber-reports/cucumber-usage.json",
		"junit:com/results/cucumber-reports/cucumber-results.xml" }, features = { "com/upi/cucumber/feature" }, glue = {

				"upi.cucumber.steps" }, tags = { "@upi" })

public class RunCucumberFeatures extends ExtendedTestNGRunner {

}