package upi.cucumber.steps;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import org.testng.asserts.SoftAssert;

import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.runtime.CucumberException;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import upi.TestUtils.Encrypt;
import upi.TestUtils.Util;

//import io.codearte.jfairy.Fairy;
//import io.codearte.jfairy.producer.person.Person;

public class BaseSteps {

	private RequestSpecification request = RestAssured.with();
	private Response response;
	String baseUrl;
	String respValue;
	String nonPrimaryVpaId;
	String primaryVpaId;
	String mobileNumber;

	SoftAssert softAssert = new SoftAssert();

	Properties configProperty;

	HashMap<String, Object> map = new HashMap<String, Object>();

	static JSONObject base = null;

	String jsonData = null;
	Util util = new Util();

	Connection conn = null;
	Statement stmt = null;
	ResultSet resultSet = null;

	final static Logger logger = Logger.getLogger(BaseSteps.class);

	@Before(order = 1)
	public void request_with_baseurl() {

		try {
			FileInputStream fi = new FileInputStream(
					new File(System.getProperty("user.dir") + "//com//upi//resources//config.properties"));
			configProperty = new Properties();
			try {
				configProperty.load(fi);
			} catch (IOException e) {
				logger.error("Sorry, something wrong!", e);
			}
		} catch (FileNotFoundException e) {
			logger.error("Sorry, something wrong!", e);
		}

		baseUrl = configProperty.getProperty("baseUrl");

		RestAssured.baseURI = baseUrl;
		request = RestAssured.given();
		logger.info("baseUrl:" + baseUrl);

	}

	@Before(order = 2)
	public void connectToUPIDB(Scenario scenario) {
		try {
			System.out.println("Connecting to database");
			Class.forName("oracle.jdbc.OracleDriver").newInstance();
			String url = configProperty.getProperty("dburl_upi");
			String userName = configProperty.getProperty("dbusrname_upi");
			String password = configProperty.getProperty("dbusrpwd_upi");
			// Open a connection
			conn = DriverManager.getConnection(url, userName, password);

		} catch (Exception exception) {
			exception.printStackTrace();
			// logger.info("unable to connect to database");
		}
	}

	@When("^user hits \"(.*?)\" (.*?) api$")
	public void api_request_is_made(String uri, String method) {
		try {
			logger.info("URI : " + uri);
			if (uri.contains("respValue")) {
				System.out.println("respValue" + respValue);
				uri = uri.replace("respValue", respValue);
				logger.info("URI : " + uri);
			}
			if (method.equalsIgnoreCase("get")) {
				response = request.log().all().when().get(uri);
			} else if ((method.equalsIgnoreCase("post")))
				response = request.log().all().when().post(uri);
			else if (method.equalsIgnoreCase("put"))
				response = request.log().all().when().put(uri);
			else if (method.equalsIgnoreCase("delete"))
				response = request.log().all().when().delete(uri);

			logger.info("Response:");
			response.prettyPrint();
		} catch (Exception e) {
			logger.error("Sorry, something wrong!", e);
		} finally {
			request = RestAssured.with();
			request.given().baseUri(baseUrl);
		}
	}

	@Then("^the status code is (\\d+)$")
	public void verify_status_code(int statusCode) {
		// response.prettyPrint();
		response.then().statusCode(statusCode);
	}

	@And("^Returned json schema is \"(.*?)\"$")
	public void schema_is(String fileName) {
		String basePath = configProperty.getProperty("schema.path");
		try {
			File file = new File(basePath + fileName);
			response.then().body(matchesJsonSchema(file));
		} catch (Exception e) {
			logger.error("Sorry, something wrong!", e);
		}
	}

	@And("^get the (.*?) from the response$")
	public String get_the_value_from_response(String key) {
		Object valueFromResp = response.then().extract().body().jsonPath().get(key);
		System.out.println("valueFromResp" + valueFromResp);
		if (valueFromResp instanceof ArrayList) {
			ArrayList arrayId = ((ArrayList) valueFromResp);
			respValue = arrayId.get(0).toString();
		} else if (valueFromResp instanceof Integer) {
			int temp = ((Integer) valueFromResp);
			respValue = String.valueOf(temp);
		} else {
			respValue = valueFromResp.toString();
		}
		System.out.println("respValue:" + respValue);
		return respValue;
	}

	public String getNewMobileNumber() {
		Random generator = new Random();
		String myString = "9";

		int random0 = generator.nextInt(1000000000);
		mobileNumber = myString + (Integer.toString(random0));

		return mobileNumber;
	}

	@Given("^Request headers$")
	public void request_headers_are(DataTable headerParams) {
		String salt = configProperty.getProperty("salt");
		try {
			List<Map<String, String>> data = headerParams.asMaps(String.class, String.class);
			for (int i = 0; i < data.size(); i++) {
				String keyMain = data.get(i).get("key");
				String keyValue = data.get(i).get("value");
				if (keyMain.equalsIgnoreCase("jwt_payload")) {
					try {
						keyValue = util.readJsonDataFromFile(keyValue);
					} catch (Throwable e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else if (keyValue.equalsIgnoreCase("randomMobileNum")) {
					keyValue = getNewMobileNumber();

				} else if (keyValue.equalsIgnoreCase("prevRandomMobileNum")) {
					keyValue = mobileNumber;

				} else if (keyMain.equalsIgnoreCase("password")) {

					logger.info("Json file:" + keyValue);
					try {
						if (keyValue.equalsIgnoreCase("updated_json")) {
							jsonData = base.toString();
						} else
							jsonData = util.readJsonDataFromFile(keyValue);
					} catch (Throwable e1) {
						// TODO Auto-generated catch block

						logger.error("Sorry, something wrong!", e1);
					}
					base = new JSONObject(jsonData);

					keyValue = base.getString("txnType") + "#" + base.getString("channel") + "#"
							+ base.getString("partnerTranId") + "#" + base.getString("stan") + "#"
							+ base.getString("acqBank") + "#" + salt;
					logger.info("keyValue" + keyValue);

					Encrypt e = new Encrypt();
					keyValue = e.generateSha512Hash(keyValue);
					System.out.println("Hash keyValue" + keyValue);
				}
				map.put(keyMain, keyValue);
			}
			request.given().headers(map).log().all();
		} catch (Exception e) {
			logger.error("Sorry, something wrong!", e);

		}
	}

	@And("^Request params$")
	public void request_params_are(DataTable reqParams) {
		try {
			List<Map<String, String>> data = reqParams.asMaps(String.class, String.class);
			for (int i = 0; i < data.size(); i++) {
				String keyMain = data.get(i).get("key");
				String keyValue = data.get(i).get("value");

				map.put(keyMain, keyValue);
			}
			request.given().params(map).log().all();
		} catch (Exception e) {
			logger.error("Sorry, something wrong!", e);

		}
	}

	@And("^Request body as json$")
	public void request_body_as_json(DataTable jsonParams) {
		String jsonFileName;

		try {
			List<Map<String, String>> data = jsonParams.asMaps(String.class, String.class);
			jsonFileName = data.get(0).get("value");
			logger.info("Json file:" + jsonFileName);
			if (jsonFileName.contains("response")) {
				jsonData = response.body().prettyPrint();
			} else {
				jsonData = util.readJsonDataFromFile(data.get(0).get("value"));
			}

			base = new JSONObject(jsonData);
			for (int i = 1; i < data.size(); i++) {
				String keyMain = data.get(i).get("key");
				String keyValue = data.get(i).get("value");
				if (keyValue.equalsIgnoreCase("randomString")) {
					String randomStringValue = "TESTAUTOMATION" + util.randomAlphaNumeric(5).toUpperCase();
					System.out.println("randomStringValue:" + randomStringValue);
					keyValue = randomStringValue;
				} else if (keyValue.equalsIgnoreCase("randomVPA")) {
					String randomVpaValue = "testautomation" + util.randomAlphaNumeric(2).toLowerCase() + "@airtel";
					System.out.println("randomVpaValue:" + randomVpaValue);
					keyValue = randomVpaValue;
				} else if (keyValue.equalsIgnoreCase("nonPrimaryVpaId")) {
					keyValue = nonPrimaryVpaId;
				} else if (keyValue.equalsIgnoreCase("primaryVpaId")) {
					keyValue = primaryVpaId;
				} else if (keyValue.equalsIgnoreCase("randomint")) {
					keyValue = String.valueOf(util.randomInt(900000));
				} else if (keyValue.contains("respValue")) {
					System.out.println("respValue" + respValue);
					keyValue = respValue;

				} else if (keyValue.contains("config")) {
					String[] arrayId = keyValue.split(":");
					keyValue = configProperty.getProperty(arrayId[1]);
				} else if (keyValue.contains("response")) {
					if (keyValue.contains(":")) {
						String jsonKey = keyValue.split(":")[1];
						Object tempValue = get_the_value_from_response(jsonKey);
						keyValue = tempValue.toString();
					}

					else {
						keyValue = respValue;
					}
				} else if (keyValue.contains("db")) {
					String[] arrayId = keyValue.split(":");
					// String queryNew = configProperty.getProperty(arrayId[2]);

					String query = arrayId[1];
					System.out.println("queryNew" + query);

					keyValue = Util.getValueFromDB(conn, query);
				}

				base = util.update(base, keyMain, keyValue);

			}
			// // Write JSON file
			// FileWriter file = new FileWriter(jsonFileName);
			//
			// file.write(base.toString());

			request.given().contentType(ContentType.JSON).body(base.toString());

		} catch (

		Throwable t) {
			logger.error("Sorry, something wrong!", t);
			fail("unable to read the json file");
		}

	}

	@And("^Response body should contain \"(.*?)\"$")
	public void response_should_contain(String message) {
		response.then().body(containsString(message));
	}

	@And("^Response body should not contain \"(.*?)\"$")
	public void response_body_should_not_contain(String message) {
		response.then().body(not(containsString(message)));
	}

	@And("^Response should contain (\\d+)$")
	public void response_should_contain(int message) {
		response.then().equals(message);
	}

	@And("^Validate the DB details$")
	public void get_value_from_db(DataTable jsonParams) throws Throwable {
		try {
			List<Map<String, String>> data = jsonParams.asMaps(String.class, String.class);

			for (int i = 0; i < data.size(); i++) {
				String key = data.get(i).get("key");
				String value = data.get(i).get("value");

				if (key.contains("response")) {
					key = key.replace("response", "");
					if (key.contains(":")) {
						String jsonKey = key.split(":")[1].replace("'", "");
						Object tempValue = get_the_value_from_response(jsonKey);
						key = key.split(":")[0] + tempValue.toString() + "'";
					}
				} else if (key.contains("updated_json")) {
					key = key.replace("updated_json", "");
					if (key.contains(":")) {
						String jsonKey = key.split(":")[1].replace("'", "");
						Object tempValue = base.get(jsonKey);
						key = key.split(":")[0] + tempValue.toString() + "'";
					}
				} else if (key.contains("randomMobileNum")) {
					System.out.println("mobileNumber" + mobileNumber);
					key = key.replace("randomMobileNum", mobileNumber);

				} else if (key.contains("respValue")) {
					System.out.println("respValue" + respValue);
					key = key.replace("respValue", respValue);

				}

				System.out.println("Query:" + key);

				assertEquals(Util.getValueFromDB(conn, key), value);

			}
		}

		catch (CucumberException e) {
			// Assertion failing
			softAssert.fail("assertion failed!!");
		}

	}

	@And("^Wait for db to update$")
	public void wait_for_db_to_update() throws InterruptedException {
		Thread.sleep(3000);
	}

	@Then("^Response body should contain data$")
	public void response_should_contain_data(DataTable jsonParams) throws Throwable {

		JsonPath jsonPath = JsonPath.from(response.asString());

		System.out.println("jsonPath" + jsonPath);
		List<Map<String, String>> data = jsonParams.asMaps(String.class, String.class);

		for (int i = 0; i < data.size(); i++) {
			String key = data.get(i).get("key");
			String valueWithPath = data.get(i).get("value");
			String value = valueWithPath.split(":")[0];
			String path = valueWithPath.split(":")[1];
			if ("not_null".equals(value)) {
				assertNotNull(jsonPath.getString(path));
			} else {
				try {
					// assertThat(jsonPath.getString(path),containsString(value));

					assertEquals(jsonPath.getString(path).toUpperCase(), value.toUpperCase());
				} catch (CucumberException e) {
					// Assertion failing
					softAssert.fail("assertion failed!!");
				}

			}

		}
	}

	@After
	public void softAssertionTest() {
		// Collates the assertion results and marks test as pass or fail
		softAssert.assertAll();
	}

	@And("^Fetch the primary and non primary VpaId$")
	public void fetch_non_primary_vpaid(DataTable jsonParams) throws Throwable {

		try {
			List<Map<String, String>> data = jsonParams.asMaps(String.class, String.class);
			for (int i = 0; i < data.size(); i++) {
				String keyValue = data.get(i).get("value");
				if (keyValue.contains("response")) {
					if (keyValue.contains(":")) {
						String jsonKey = keyValue.split(":")[1];
						System.out.println("Jsonkey" + jsonKey);
						Object valueFromResp = response.then().extract().body().jsonPath().get(jsonKey);
						System.out.println("valueFromResp" + valueFromResp.toString());

						if (valueFromResp instanceof ArrayList) {
							ArrayList arrayId = ((ArrayList) valueFromResp);
							for (int j = 0; j < arrayId.size(); j++) {
								// Object jsonObj=arrayId.get(j);
								HashMap jsonObj = (HashMap) arrayId.get(j);
								if (jsonObj.get("primary").toString().equals("false")) {
									System.out.println("jsonObj : " + jsonObj.toString());
									System.out.println("vpaId : " + jsonObj.get("vpaId"));
									nonPrimaryVpaId = jsonObj.get("vpaId").toString();
								} else if (jsonObj.get("primary").toString().equals("true")) {
									System.out.println("jsonObj : " + jsonObj.toString());
									System.out.println("vpaId : " + jsonObj.get("vpaId"));
									primaryVpaId = jsonObj.get("vpaId").toString();
								}

							}

						}
					}
				}

			}
		} catch (Throwable t) {
			logger.error("Sorry, something wrong!", t);
			fail("unable to read the json file");
		}

	}

	// @And("^Response should contain$")
	// public void response_should_contain_data(DataTable responseParams) {
	// System.out.println("Response should contain:");
	// List<Map<String, String>> data = responseParams.asMaps(String.class,
	// String.class);
	// for (int j = 0; j < data.size(); j++) {
	// String keyMain = data.get(j).get("key");
	// String keyValue = data.get(j).get("value");
	// if (keyValue.equals("response")) {
	// keyValue = respValue;
	// } else if (keyValue.contains("dbValue")) {
	// keyValue = dbValue;
	// } else if (keyValue.contains("randomValue")) {
	// String[] temp = keyValue.split("randomValue");
	// if (temp.length >= 1)
	// keyValue = temp[0] + randomValue.toString();
	// else
	// keyValue = randomValue.toString();
	// } else if (keyValue.equals("loggedInUserId")) {
	// keyValue = loggedInUserIdConfig;
	// } else if (keyValue.equals("brandId")) {
	// keyValue = brandIdConfig;
	// } else if (keyValue.contains("inputData")) {
	// if (keyValue.contains(":")) {
	// String key = keyValue.split(":")[1];
	// if (key.contains("_dt")) {
	// key = key.replace("_dt", "");
	// if (key.equalsIgnoreCase("triggerDay")) {
	// // int
	// // hr=Integer.valueOf(inputData.get("triggerHr").toString());
	// // int
	// // min=Integer.valueOf(inputData.get("triggerMin").toString());
	// Long keyVal = Long.valueOf(inputData.get(key).toString());
	// Date baseDt = new Date(keyVal);
	// Date triggerTime = util.storeTriggerTime(0, 0, baseDt);
	//
	// System.out.println("time:" + inputData.get(key));
	// long millis = triggerTime.getTime();
	// inputData.put(key, millis);
	// System.out.println("triggerTime:" + millis);
	// }
	// Long keyVal = Long.valueOf(inputData.get(key).toString());
	// Long respValue = Long.valueOf(((List)
	// response.path(keyMain)).get(0).toString());
	// Long lowerBound = respValue - 30000;
	// Long upperBound = respValue + 30000;
	// if (keyVal > lowerBound && keyVal < upperBound) {
	// inputData.put(key, respValue);
	// }
	// }
	// keyValue = inputData.get(key).toString();
	// System.out.println("keyValue:" + keyValue);
	// }
	// }
	// assertThat(response.path(keyMain).toString(), containsString(keyValue));
	// }
	// }

	// @And("^Response should not contain$")
	// public void response_should_not_contain_data(DataTable responseParams) {
	// List<Map<String, String>> data = responseParams.asMaps(String.class,
	// String.class);
	// for (int j = 0; j < data.size(); j++) {
	// String keyMain = data.get(j).get("key");
	// String keyValue = data.get(j).get("value");
	// if (keyValue.contains("response")) {
	// keyValue = respValue;
	// } else if (keyValue.contains("loggedInUserId")) {
	// keyValue = loggedInUserIdConfig;
	// }
	// assertThat("verification successful", response.path(keyMain).toString(),
	// not(equals(keyValue)));
	// }
	// }

}
