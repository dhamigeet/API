package upi.TestUtils;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Base64;

public class DBConnection {	
	
	public static Connection conn = null;
	public static Statement stmt = null;
	public static ResultSet resultSet = null;
	public static String OTPEncodeValue = null;
	public static byte[] OTPDecodeByteValue = null;
	
	public static String getOTP(String dburl, String dbusername, String dbusrpwd, String mobilenumber) throws IOException {
			
			String OTPEncodeValue = null;
			byte[] OTPDecodeByteValue = null;
			String queryValue = "select * from (select OTPCODE from ONETIMEPASSWORDPRODUCT where MSISDN = 91" + mobilenumber + "order by GENERATED_ON desc) where rownum = 1";
			Connection conn = null;
			Statement stmt = null;
			ResultSet resultSet = null;
			
			try {
				
				Class.forName("oracle.jdbc.OracleDriver").newInstance();
				// Open a connection
				conn = DriverManager.getConnection(dburl, dbusername, dbusrpwd);
			
				// Execute a query
				stmt = conn.createStatement();
				
				resultSet = stmt.executeQuery(queryValue);
				while (resultSet.next()) {
					
					OTPEncodeValue = resultSet.getString("OTPCODE");
					//System.out.println("The OTP Encoded value is :- " + OTPEncodeValue);
				}
				if (resultSet != null) {
					try {
						resultSet.close();
					} catch (Exception e) {
					}
				}
				
				if (stmt != null) {
					try {
						stmt.close();
					} catch (Exception e) {
					}
				}
				
				if (conn != null) {
					try {
						conn.close();
					} catch (Exception e) {
					}
				}
			} catch (Exception e) {
				System.out.println(e);
			}
			
			OTPDecodeByteValue = Base64.getDecoder().decode(OTPEncodeValue);
			String OTPDecodeValue = new String(OTPDecodeByteValue, "UTF-8");
			
			System.out.println("The OTP Decoded value is :- " + OTPDecodeValue);
			
			return OTPDecodeValue;
			
		}

}


