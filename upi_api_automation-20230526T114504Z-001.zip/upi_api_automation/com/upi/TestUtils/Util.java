package upi.TestUtils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Iterator;
import java.util.concurrent.ThreadLocalRandom;

import org.json.JSONArray;
import org.json.JSONObject;

public class Util {

	private static final String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

	public JSONObject update(JSONObject obj, String keyMain, Object newValue) throws Exception {
		// We need to know keys of Jsonobject
		JSONObject json = new JSONObject();
		Iterator iterator = obj.keys();
		String key = null;
		while (iterator.hasNext()) {
			key = (String) iterator.next();
			if ((obj.optJSONArray(key) == null) && (obj.optJSONObject(key) == null)) {
				if ((key.equals(keyMain))) {
					obj.put(key, newValue);
				}
			}
			if (obj.optJSONObject(key) != null) {
				update(obj.getJSONObject(key), keyMain, newValue);
			}
			if (obj.optJSONArray(key) != null) {
				if (key.contains("Ids") || key.contains("IdList") || key.contains("placeholders")) {
					if ((key.equals(keyMain))) {
						JSONArray jArray = new JSONArray();
						if (newValue.toString().contains(",")) {
							String[] valueArray = newValue.toString().split(",");
							for (int i = 0; i < valueArray.length; i++) {
								jArray.put(Integer.parseInt(valueArray[i]));
							}
						} else {
							if (!(newValue.toString().isEmpty())) {
								jArray.put(Integer.parseInt(newValue.toString()));
							}
						}
						obj.put(key, jArray);
					}
				} else {
					JSONArray jArray = obj.getJSONArray(key);
					for (int i = 0; i < jArray.length(); i++) {
						update(jArray.getJSONObject(i), keyMain, newValue);
					}
				}
			} else if (keyMain.contains("placeholders")) {
				if ((key.equals(keyMain))) {
					JSONArray jArray = new JSONArray();
					if (newValue.toString().contains(",")) {
						String[] valueArray = newValue.toString().split(",");
						for (int i = 0; i < valueArray.length; i++) {
							jArray.put(Integer.parseInt(valueArray[i]));
						}
					} else {
						if (!(newValue.toString().isEmpty())) {
							jArray.put(Integer.parseInt(newValue.toString()));
						}
					}
					obj.put(key, jArray);
				}
			}
		}
		return obj;
	}

	public String randomAlphaNumeric(int count) {
		StringBuilder builder = new StringBuilder();
		while (count-- != 0) {
			int character = (int) (Math.random() * ALPHA_NUMERIC_STRING.length());
			builder.append(ALPHA_NUMERIC_STRING.charAt(character));
		}
		return builder.toString();
	}

	public int randomInt(int max) {
		int randomNum = 0;
		randomNum = ThreadLocalRandom.current().nextInt(4000, max + 1);
		return randomNum;
	}

	public String readJsonDataFromFile(String arg1) throws Throwable {
		String json;
		FileInputStream fin = new FileInputStream(
				new File(System.getProperty("user.dir") + "//com//upi//resources//testData//" + arg1));
		InputStreamReader in = new InputStreamReader(fin);
		BufferedReader bufferedReader = new BufferedReader(in);
		StringBuilder sb = new StringBuilder();
		String line;
		while ((line = bufferedReader.readLine()) != null) {
			sb.append(line);
		}
		json = sb.toString();
		System.out.println(json);
		return json;
	}

	public static String getValueFromDB(Connection con, String sql) throws Exception {
		String value = "";
		Statement stmt;
		stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		while (rs.next()) {
			value = rs.getString(1);
			break;
		}
		return value;
	}

}
