package upi.TestUtils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Encrypt {
	
	 public  String generateSha512Hash(String message) throws NoSuchAlgorithmException {
	        MessageDigest md;
	        String out = "";
	        try {
	            md= MessageDigest.getInstance("SHA-512");

	            md.update(message.getBytes());
	            byte[] mb = md.digest();
	            for (int i = 0; i < mb.length; i++) {
	                byte temp = mb[i];
	                String s = Integer.toHexString(new Byte(temp));
	                while (s.length() < 2) {
	                    s = "0" + s;
	                }
	                s = s.substring(s.length() - 2);
	                out += s;
	            }
	            System.out.println(out.length());
	            System.out.println("CRYPTO: " + out);

	        } catch (NoSuchAlgorithmException e) {
	            System.out.println("ERROR: " + e.getMessage());
	        }
	        return out;
	}

}
