package com.UPIApp.TestUtils;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;

public class DriverFactory {

    public static String chromeExeFilePath;

    public static String getChromeExeFilePath() {
        return chromeExeFilePath;
    }

    public static void setChromeExeFilePath(String chromeExeFilePath) {
        DriverFactory.chromeExeFilePath = chromeExeFilePath;
    }

    @SuppressWarnings("rawtypes")
    public AndroidDriver<?> createDriverInstance(String platformname,
            String devicename, String platformversion, String apppackage,
            String appactivity) {
        AndroidDriver<?> driver = null;

        if (platformname.equalsIgnoreCase("firefox")) {

        } else if (platformname.equalsIgnoreCase("chrome")) {

        } else if (platformname.equalsIgnoreCase("ie")) {

        } else if (platformname.equalsIgnoreCase("Android")) {
            DesiredCapabilities cap = new DesiredCapabilities();

            cap.setCapability(MobileCapabilityType.PLATFORM_NAME, platformname);
            cap.setCapability(MobileCapabilityType.DEVICE_NAME, "Android");
            cap.setCapability(MobileCapabilityType.PLATFORM_VERSION,
                    platformversion);
            cap.setCapability(
                    AndroidMobileCapabilityType.AUTO_GRANT_PERMISSIONS, true);
            cap.setCapability(MobileCapabilityType.AUTOMATION_NAME,
                    "UiAutomator2");
            cap.setCapability(AndroidMobileCapabilityType.APP_PACKAGE,
                    apppackage);
            cap.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY,
                    appactivity);

            // Vishal start
            cap.setCapability(MobileCapabilityType.CLEAR_SYSTEM_FILES, true);
            // cap.setCapability(MobileCapabilityType.NO_RESET, true);
            cap.setCapability("disableWindowAnimation", true);
            cap.setCapability("autoAcceptAlerts", true);
            // Skip the installation of io.appium.settings app and the
            // UIAutomator 2 server.
            cap.setCapability("skipDeviceInitialization", true);
            cap.setCapability("skipServerInstallation", true);
            // cap.setCapability("isHeadless", true);
            // cap.setCapability(AndroidMobileCapabilityType.IGNORE_UNIMPORTANT_VIEWS,
            // true);
            // cap.setCapability(AndroidMobileCapabilityType.DISABLE_ANDROID_WATCHERS,
            // true);
            // cap.setCapability("useNewWDA", "true");
            // cap.setCapability("waitForQuiescence", "false");// starts test
            // before the app has started.
            cap.setCapability("clearSystemFiles", true);
            // Vishal stop
            try {

                driver = new AndroidDriver(
                        new URL("http://127.0.0.1:4723/wd/hub"), cap);
                DriverManager.setDriver(driver);

                // driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);

            } catch (MalformedURLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        } else {

        }
        return driver;
    }

    public static void destory() {
        DriverManager.getDriver().quit();
    }
}
