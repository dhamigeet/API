package com.UPIApp.TestUtils;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Base64;

public class DBConnection {
	
	public static byte[] OTPDecodeByteValue = null;
	
	public String setUpOTPDBConnection(String dburl, String dbusername, String dbusrpwd, String mobilenumber) throws IOException {
		
		String OTPEncodeValue = null;
		byte[] OTPDecodeByteValue = null;
		String queryValue = "select * from (select OTPCODE from ONETIMEPASSWORDPRODUCT where MSISDN = 91" + mobilenumber + "order by GENERATED_ON desc) where rownum = 1";
		Connection conn = null;
		Statement stmt = null;
		ResultSet resultSet = null;
		
		try {
			
			Class.forName("oracle.jdbc.OracleDriver").newInstance();
			// Open a connection
			conn = DriverManager.getConnection(dburl, dbusername, dbusrpwd);
		
			// Execute a query
			stmt = conn.createStatement();
			
			resultSet = stmt.executeQuery(queryValue);
			while (resultSet.next()) {
				
				OTPEncodeValue = resultSet.getString("OTPCODE");
				//System.out.println("The OTP Encoded value is :- " + OTPEncodeValue);
			}
			if (resultSet != null) {
				try {
					resultSet.close();
				} catch (Exception e) {
				}
			}
			
			if (stmt != null) {
				try {
					stmt.close();
				} catch (Exception e) {
				}
			}
			
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception e) {
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		
		OTPDecodeByteValue = Base64.getDecoder().decode(OTPEncodeValue);
		String OTPDecodeValue = new String(OTPDecodeByteValue, "UTF-8");
		
		//System.out.println("The OTP Decoded value is :- " + OTPDecodeValue);
		
		return OTPDecodeValue;
	}
	
	public static String getValueFromDB(String dbcon, String databaseusername, String databaseusrpwd, String querystr) throws Exception
	{
		
		String value = "";
        Statement stmt;
        
        try {
        	
        	Class.forName("oracle.jdbc.OracleDriver").newInstance();
			Connection con = DriverManager.getConnection(dbcon, databaseusername, databaseusrpwd);
            
            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(querystr);
            while(rs.next()) {
            	value = rs.getString(1);
                break;
            }
        }catch (Exception e) {
			System.out.println(e);
		}
        
        
       return value;
	}
	
	public static String getDecodedOTP (String dburl, String dbusername, String dbusrpwd, String querystring) throws Exception {
		
		String OTPencodevalue = "";
		String OTPdecodevalue = "";
		OTPencodevalue = getValueFromDB(dburl, dbusername, dbusrpwd, querystring);
		
		OTPDecodeByteValue = Base64.getDecoder().decode(OTPencodevalue);
		OTPdecodevalue = new String(OTPDecodeByteValue, "UTF-8");
        
        return OTPdecodevalue;
		
	}
}
