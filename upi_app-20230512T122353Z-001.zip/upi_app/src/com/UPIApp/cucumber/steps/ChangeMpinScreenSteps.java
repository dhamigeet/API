package com.UPIApp.cucumber.steps;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.UPIApp.TestUtils.DriverManager;
import com.UPIApp.cucumber.tests.RunCucumberFeatures;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class ChangeMpinScreenSteps extends BaseSteps {

    @Then("^I should see Change mPIN result screen with \"([^\"]*)\"$")
    public void iShouldSeeChangeMpinResultScreen(String msg) throws Throwable {
        Thread.sleep(6000);
        waitForElement(By
                .id(RunCucumberFeatures.locators.getProperty("txt_mPIN_msg")));
        WebElement txt_mPIN_msg = DriverManager.getDriver().findElement(By
                .id(RunCucumberFeatures.locators.getProperty("txt_mPIN_msg")));
        assertTrue(txt_mPIN_msg.getText().contains(msg));
        System.out.println(txt_mPIN_msg.getText());
        WebElement title_mPin_header1 = DriverManager.getDriver()
                .findElement(By.xpath(RunCucumberFeatures.locators
                        .getProperty("title_mPin_header")));
        assertTrue(title_mPin_header1.isDisplayed());

    }

    @And("^I click on OK$")
    public void iClickOnOK() throws Throwable {
        WebElement btn_mPIN_ok = DriverManager.getDriver().findElement(
                By.id(RunCucumberFeatures.locators.getProperty("btn_mPIN_ok")));
        System.out.println("--" + btn_mPIN_ok.getText());
        btn_mPIN_ok.click();
        Thread.sleep(2000);
    }

}
