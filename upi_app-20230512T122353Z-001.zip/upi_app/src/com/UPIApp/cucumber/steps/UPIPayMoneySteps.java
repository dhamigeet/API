package com.UPIApp.cucumber.steps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.UPIApp.TestUtils.DBConnection;
import com.UPIApp.TestUtils.DriverManager;
import com.UPIApp.cucumber.tests.RunCucumberFeatures;

public class UPIPayMoneySteps extends BaseSteps {
	
	public static String vpa_bankaccount = null;
	
    @Then("^I should see \"([^\"]*)\"$")
    public void iAmAbleToClickChangeVPA(String paymoneytabs) throws Throwable {
		ArrayList <String> paymoney_tabs = new ArrayList<String>();
		
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("tabs_paymoney")));
    	WebElement tabs_paymoney = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("tabs_paymoney")));
    	
    	List<WebElement> allpaymoneytabs = tabs_paymoney.findElements(By.id(RunCucumberFeatures.locators.getProperty("tab_paymoney")));
    	
    	for (int i = 0; i< allpaymoneytabs.size(); i++) {
    		  String text = allpaymoneytabs.get(i).getText().trim();
    			paymoney_tabs.add(text);
    	}
    	
    	Collections.sort(paymoney_tabs);
    	String[] tabvalues = paymoneytabs.split(", ");
    	List <String> tabvaluesList = Arrays.asList(tabvalues);
    	Collections.sort(tabvaluesList);  	
    	assertEquals(tabvaluesList, paymoney_tabs);
    }
    
    @Then("^I should see VPA fields for Pay Money$")
    public void iShouldSeePayMoneyVPAScreen() throws Throwable {
    	WebElement vpabox = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("vpabox")));
    	assertTrue(vpabox.isDisplayed());
    	
    	WebElement amountfield = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_paymoney_amount")));
    	assertTrue(amountfield.isDisplayed());
    	
    	WebElement remarksfield = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_paymoney_remarks")));
    	assertTrue(remarksfield.isDisplayed());
    	
    	WebElement btnproceed = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("btn_proceed_paymoney")));
    	assertTrue(btnproceed.isDisplayed());
    }
    
    @And("^I fill \"([^\"]*)\" as vpa for Pay Money$")
    public void iAmAbleToFillVPA(String vpa) throws Throwable {  	
    	WebElement txtbox_paymoneyvpa = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_paymoney_vpa")));
    	txtbox_paymoneyvpa.clear();
    	txtbox_paymoneyvpa.sendKeys(vpa);
    }
    
    @And("^I fill Bank Account Linked VPA for pay money$")
    public void iAmAbleToFillVPABankAccountLink_PayMoney() throws Throwable {
    	
    	String vpa_bankaccountquery = "select VPA from UPI_VPA t1  INNER JOIN UPI_ACCOUNT t2 ON t1.customer_id = t2.customer_id where t1.STATUS = 'ACTIVE'";
    	vpa_bankaccount = DBConnection.getValueFromDB(configProperty.getProperty("dburl"), configProperty.getProperty("dbusrname"), configProperty.getProperty("dbusrpwd"), vpa_bankaccountquery);
    	
    	WebElement txtbox_paymoneyvpa = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_paymoney_vpa")));
    	txtbox_paymoneyvpa.sendKeys(vpa_bankaccount);
    }
    
    @Then("^I should see green icon with valid VPA status$")
    public void iShouldSeeGreenIconForValidVPA() throws Throwable {
    	
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("icon_validvpa")));
    	WebElement icon_validvpa = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("icon_validvpa")));
    	assertTrue(icon_validvpa.isDisplayed());
    	
    	WebElement txt_successvpa = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txt_successvpa")));
    	assertTrue(txt_successvpa.isDisplayed());
    }
    
    @And("^I click on Proceed button for Pay Money$")
    public void iAmAbleToClickProceedButton_PayMoney() throws Throwable {
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("btn_proceed_paymoney")));
    	TouchAction t = new TouchAction(DriverManager.getDriver());
    	t.press(PointOption.point(22,673)).moveTo(PointOption.point(22,550)).release().perform();
    	
    	WebElement btnproceed = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("btn_proceed_paymoney")));
    	btnproceed.click();
    }
    
    @Then("^I should see \"([^\"]*)\" as Default Remarks text for Pay Money$")
    public void iShouldSeeRemarksField_PayMoney(String text) throws Throwable {
    	String msg = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_paymoney_remarks"))).getText().trim();
    	assertEquals(msg, text);
    }
    
    
    @And("^I fill \"([^\"]*)\" as remarks for Pay Money$")
    public void iAmAbleToFillRemarks(String remarks) throws Throwable {
    	WebElement txtbox_remarks = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_paymoney_remarks")));
    	txtbox_remarks.clear();
    	txtbox_remarks.click();
    	txtbox_remarks.sendKeys(remarks);
    	DriverManager.getDriver().navigate().back();
    	
    }
    
    @Then("^I should see max characters in remarks field$")
    public void iShouldSeeMaxCharactersInRemarks() throws Throwable {
    	WebElement txtbox_remarks = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_paymoney_remarks")));
    	assertTrue(txtbox_remarks.getText().length() == 50);
    }
    
    @And("^I fill \"([^\"]*)\" as amount for Pay Money$")
    public void iAmAbleToFillAmount_PayMoney(String amt) throws Throwable {
    	WebElement amountfield = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_paymoney_amount")));
    	amountfield.clear();
    	amountfield.sendKeys(amt);
    }
    
    @And("^I click on ACC NO. IFSC tab$")
    public void iAmAbleToClickAccNoIFSCTab() throws Throwable {
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("tabs_paymoney")));
		WebElement AccNoIFSCtab = DriverManager.getDriver().findElement(By.xpath(RunCucumberFeatures.locators.getProperty("tab_AccNoIFSC")));
		AccNoIFSCtab.click();
    }
    
    @And("^I click on Send Now button for Pay Money$")
    public void iAmAbleToClickSendNowButton_PayMoney() throws Throwable {
    	try {
    		WebElement btnsendnow = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("btnsendnow")));
        	btnsendnow.click();
        	
        //	DriverManager.getDriver().hideKeyboard();
        	
    	} catch (Exception e) {
    		
    	}
    }
    
    @And("^I fill account holdername as \"([^\"]*)\"$")
    public void iAmAbleToFillAccountHolderName(String accholdername) throws Throwable {
    	WebElement txtbox_accholdername = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_accholdername")));
    	txtbox_accholdername.clear();
    	txtbox_accholdername.sendKeys(accholdername);
    	DriverManager.getDriver().hideKeyboard();
    }
    
    @And("^I fill account number as \"([^\"]*)\"$")
    public void iAmAbleToFillAccountNumber(String accnumber) throws Throwable {
    	WebElement txtbox_accnumber = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_accnumber")));
    	txtbox_accnumber.clear();
    	txtbox_accnumber.sendKeys(accnumber);
    	DriverManager.getDriver().hideKeyboard();
    }
    
    @And("^I fill bank as \"([^\"]*)\" for pay money$")
    public void iAmAbleToFillPayMoney(String bank) throws Throwable {
    	WebElement lnk_selectbank = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_selectbank")));
    	lnk_selectbank.click();
    	
    	waitForElement(By.xpath(RunCucumberFeatures.locators.getProperty("title_choosebank")));
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_srchbank")));
    	VPACreationSteps.selectBank(bank);
    }
    
    @And("^I fill IFSC Code with \"([^\"]*)\" as state \"([^\"]*)\" as city and \"([^\"]*)\" as region$")
    public void iAmAbleToFillIFSC_PayMoney(String sta, String dis, String reg) throws Throwable {
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_selectifsc")));
    	WebElement lnk_selectifsccode = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_selectifsc")));
    	lnk_selectifsccode.click();
    	
    	selectIFSC(sta, dis, reg);
    	
    }
    
    public void selectIFSC(String state, String district, String region) {
    	waitForElement(By.xpath(RunCucumberFeatures.locators.getProperty("title_selectstate")));
		selectElementFromList(state);
		
		waitForElement(By.xpath(RunCucumberFeatures.locators.getProperty("title_selectdistrict")));
		selectElementFromList(district);
		
		waitForElement(By.id(RunCucumberFeatures.locators.getProperty("txt_options_item")));
		WebElement listbox = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("lst_options")));
		List <WebElement> lst_optionitems = listbox.findElements(By.id(RunCucumberFeatures.locators.getProperty("txt_options_item")));
		
		for(int i = 0; i < lst_optionitems.size(); i++) {
			String item = lst_optionitems.get(i).getText().trim();
			if (item.equalsIgnoreCase(region)) {
				lst_optionitems.get(i).click();
				break;
			}
		}
		
		waitForElement(By.id(RunCucumberFeatures.locators.getProperty("btn_selectifsc")));
		WebElement btn_selectifsc = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("btn_selectifsc")));
		btn_selectifsc.click();
		
	}
    
    @Then("^I should see \"([^\"]*)\" as Default Remarks text on Account IFSC tab$")
    public void iShouldSeeRemarksField_PayMoney_AccIFSCTab(String text) throws Throwable {
    	String msg = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_remarks_accifsctab"))).getText().trim();
    	assertEquals(msg, text);
    }
    
    @And("^I fill \"([^\"]*)\" as remarks for Pay Money on Acc IFSC tab$")
    public void iAmAbleToFillRemarks_AccIFSCTab(String remarks) throws Throwable {
    	WebElement txtbox_remarks = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_remarks_accifsctab")));
    	txtbox_remarks.clear();
    	txtbox_remarks.sendKeys(remarks);
    	
    	DriverManager.getDriver().hideKeyboard();
    }
    
    @And("^I fill IFSC Code as \"([^\"]*)\"$")
    public void iAmAbleToClearIFSCCode(String ifsccode) throws Throwable {
    	WebElement txtbox_ifsccode = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_ifsccode")));
    	txtbox_ifsccode.clear();
    	txtbox_ifsccode.sendKeys(ifsccode);
    	
    	DriverManager.getDriver().hideKeyboard();
    }
    
    @Then("^I should see IFSC Code field$")
    public void iShouldSeeIFSCField() throws Throwable {
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("box_ifsccode")));
    	WebElement ifsccodebox = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("box_ifsccode")));
    	assertTrue(ifsccodebox.isDisplayed());
    }
    
    @Then("I should see successful payment screen with \"([^\"]*)\"$")
    public void iShouldSeeSuccessfulPaymentScreen(String text)
    {
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("icon_pay")));
    	WebElement iconpay = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("icon_pay")));
    	assertTrue(iconpay.isDisplayed());
    	WebElement txtpay = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txt_pay")));
    	assertEquals(txtpay.getText(),text);
    }
    	
    public void selectElementFromList(String val) {
    	DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txt_srchbox"))).sendKeys(val);
		waitForElement(By.id(RunCucumberFeatures.locators.getProperty("lst_options")));
    	
		WebElement listcontainer = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("lst_options")));
		
		List<WebElement> elements = listcontainer.findElements(By.id(RunCucumberFeatures.locators.getProperty("txt_options")));
		for(int i = 0 ; i < elements.size(); i++) {
			String eleval = elements.get(i).getText().trim();
			if(eleval.equalsIgnoreCase(val)) {
				elements.get(i).click();
				break;
			}
		}
    }
    
}

