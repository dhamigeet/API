package com.UPIApp.cucumber.steps;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.UPIApp.TestUtils.DriverManager;
import com.UPIApp.cucumber.tests.RunCucumberFeatures;

import cucumber.api.java.en.And;

public class UPIMpinScreenSteps extends BaseSteps {

    @And("I enter UPI PIN for external bank$")
    public void iShouldSeeUPIScreen() throws Throwable {
        // waitForElement(By.xpath(
        // RunCucumberFeatures.locators.getProperty("txt_bankName")));
        WebElement txt_bankName = DriverManager.getDriver().findElement(By
                .id(RunCucumberFeatures.locators.getProperty("txt_bankName")));
        assertEquals(txt_bankName.getText(), "Mybene");
        System.out.println(txt_bankName.getText());

        WebElement txt_enterPin = DriverManager.getDriver().findElement(By
                .id(RunCucumberFeatures.locators.getProperty("txt_enterPin")));
        assertEquals(txt_enterPin.getText(), "ENTER UPI PIN");
        System.out.println(txt_enterPin.getText());

        WebElement txt_inputPin = DriverManager.getDriver().findElement(By
                .id(RunCucumberFeatures.locators.getProperty("txt_inputPin")));
        txt_inputPin.click();
        String usr_type = configProperty.getProperty("upi_SBA_mobnum");
        String lastSixDigits = "";
        if (usr_type.length() > 6) {
            lastSixDigits = usr_type.substring(usr_type.length() - 6);
        }
        fillKeypadValue2(lastSixDigits);
        WebElement lnk_enterok = DriverManager.getDriver().findElement(By.xpath(
                RunCucumberFeatures.locators.getProperty("lnk_enterok")));
        lnk_enterok.click();

    }

}
