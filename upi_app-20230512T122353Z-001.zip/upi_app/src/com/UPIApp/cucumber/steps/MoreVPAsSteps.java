package com.UPIApp.cucumber.steps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.UPIApp.TestUtils.DBConnection;
import com.UPIApp.TestUtils.DriverManager;
import com.UPIApp.cucumber.tests.RunCucumberFeatures;

public class MoreVPAsSteps extends BaseSteps {
	
	public static String nonprimaryvpa = null;
	public static List<WebElement> VPAlist = null;
	public static String vpa_checklinkedacc = null;
	
	@Then("^I should see More VPAs screen$")
    public void iShouldSeeMoreVPAsScreen() throws Throwable {
    	waitForElement(By.xpath(RunCucumberFeatures.locators.getProperty("title_moreVPAs")));
    	WebElement title_moreVPAs = DriverManager.getDriver().findElement(By.xpath(RunCucumberFeatures.locators.getProperty("title_moreVPAs")));
    	assertTrue(title_moreVPAs.isDisplayed());
    }
    
    @And("^I click on Non Primary VPA$")
    public void iClickVPAForDelete() {
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("allVPAsbox")));
        selectVPA(nonprimaryvpa);
    }
    
    @And("^I click on Primary VPA from More VPAs List$")
    public void iClickVPA() {
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("allVPAsbox")));
    	vpa_checklinkedacc = UPIHomeScreenSteps.primaryvpatitle;
        selectVPA(vpa_checklinkedacc);
    }  
    
    @Then("^I should not see deleted VPA in the list$")
    public void iShouldSeeDeletedVPA() throws Throwable {
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("allVPAsbox")));
    	assertEquals(isVPAPresent(nonprimaryvpa), false);
    }
    
    @Then("^I should see VPA in the VPAs list$")
    public void iShouldSeeVPAInTheVPAList() {
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("allVPAsbox")));
    	assertTrue(isVPAPresent(nonprimaryvpa));
    }
    
    @Then("^I should see VPAs list$")
    public void iShouldSeeVPAList() {
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("allVPAsbox")));
    	WebElement allVPAsbox = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("allVPAsbox")));
		VPAlist = allVPAsbox.findElements(By.className(RunCucumberFeatures.locators.getProperty("vpaclass_vpabox"))); 
		
		assertTrue(VPAlist.size() > 0);
		
    }
    
    @And("^I am able to get Non-Primary VPA$")
    public void iAmAbleToGetNonPrimaryVPA() throws Exception {
    	String nonprimaryvpanonlinkedaccquery = "select VPA from UPI_VPA b INNER JOIN UPI_CUSTOMER a ON a.CUSTOMER_ID = b.CUSTOMER_ID \r\n" + 
    			//"LEFT JOIN UPI_VPA_ACCOUNT c ON b.VPA_ID = c.VPA_ID\r\n" + 
    			//"where a.MOBILE_NUMBER = '"+LoginSteps.mobnum+"' and a.ACTOR_STATUS = 'ACTIVE' and b.IS_PRIMARY = '0' and b.STATUS = 'ACTIVE' and c.VPA_ID IS NULL";
    	"where a.MOBILE_NUMBER = '"+LoginSteps.mobnum+"' and a.ACTOR_STATUS = 'ACTIVE' and b.IS_PRIMARY = '0' and b.STATUS = 'ACTIVE'";
    	System.out.println("---"+ nonprimaryvpanonlinkedaccquery);
    	//String nonprimaryvpaquery = "select VPA from UPI_VPA where CUSTOMER_ID = '"+ LoginSteps.custID +"' and IS_PRIMARY = '0' and STATUS = 'ACTIVE'";    	
        nonprimaryvpa = DBConnection.getValueFromDB(configProperty.getProperty("dburl"), configProperty.getProperty("dbusrname"), configProperty.getProperty("dbusrpwd"), nonprimaryvpanonlinkedaccquery);
        if (nonprimaryvpa.isEmpty()) {
        	WebElement screenheader = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("screenheader")));
        	WebElement lnk_back = screenheader.findElement(By.className(RunCucumberFeatures.locators.getProperty("lnk_back")));
        	lnk_back.click();
        	
        	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_createnewVPA")));
        	WebElement lnk_createnewVPA = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_createnewVPA")));
            lnk_createnewVPA.click();
            
            String vpastring = randomVPAGenerator(8);    	
    		WebElement txtbox_createvpa = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_createvpa")));
        	txtbox_createvpa.clear();
        	txtbox_createvpa.sendKeys(vpastring);
        	DriverManager.getDriver().hideKeyboard();
        	
        	WebElement btn_vpasetup = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("btn_vpasetup")));
        	btn_vpasetup.click();
        	
        	waitForElement(By.xpath(RunCucumberFeatures.locators.getProperty("title_choosebank")));
        
        	lnk_back.click();
        	
        	waitForElement(By.xpath(RunCucumberFeatures.locators.getProperty("title_bhimupi")));
        	
        	WebElement lnk_moreVPAs = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_moreVPAs")));
        	lnk_moreVPAs.click();
        	
        	nonprimaryvpa = vpastring + "@airtel";
        	
        }
    }
    
    @And("^I am able to get Non-Primary VPA with linked Bank Account as \"([^\"]*)\"$")
    public void iAmAbleToGetNonPrimaryVPA_LinkBankAccount(String bankname) throws Exception {
    	String nonprimaryvpalinkedaccquery = "select VPA from UPI_VPA b INNER JOIN UPI_CUSTOMER a ON a.CUSTOMER_ID = b.CUSTOMER_ID \r\n" + 
    			"INNER JOIN UPI_VPA_ACCOUNT c ON b.VPA_ID = c.VPA_ID\r\n" + 
    			"where a.MOBILE_NUMBER = '"+LoginSteps.mobnum+"' and a.ACTOR_STATUS = 'ACTIVE' and b.IS_PRIMARY = '0' and b.STATUS = 'ACTIVE'";    	
       
    	nonprimaryvpa = DBConnection.getValueFromDB(configProperty.getProperty("dburl"), configProperty.getProperty("dbusrname"), configProperty.getProperty("dbusrpwd"), nonprimaryvpalinkedaccquery);
        
        if (nonprimaryvpa.isEmpty()) {
        	WebElement screenheader = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("screenheader")));
        	WebElement lnk_back = screenheader.findElement(By.className(RunCucumberFeatures.locators.getProperty("lnk_back")));
        	lnk_back.click();
        	
        	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_createnewVPA")));
        	WebElement lnk_createnewVPA = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_createnewVPA")));
            lnk_createnewVPA.click();
            
            String vpastring = randomVPAGenerator(8);    	
    		WebElement txtbox_createvpa = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_createvpa")));
        	txtbox_createvpa.clear();
        	txtbox_createvpa.sendKeys(vpastring);
        	DriverManager.getDriver().hideKeyboard();
        	
        	WebElement btn_vpasetup = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("btn_vpasetup")));
        	btn_vpasetup.click();
        	
        	waitForElement(By.xpath(RunCucumberFeatures.locators.getProperty("title_choosebank")));
        	
        	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_srchbank")));
        	VPACreationSteps.selectBank(bankname);
        	
        	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("bankaccountspopup")));
        	WebElement bankaccountspopup = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("bankaccountspopup")));
        	assertTrue(bankaccountspopup.isDisplayed());
        	
        	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("accountcontainer")));
        	WebElement allbankaccountsbox = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("accountcontainer")));
        	assertTrue(allbankaccountsbox.isDisplayed());
        
        	VPACreationSteps.selectBankAccount(bankname);
        	
        	waitForElement(By.xpath(RunCucumberFeatures.locators.getProperty("title_bhimupi")));
        	
        	WebElement lnk_moreVPAs = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_moreVPAs")));
        	lnk_moreVPAs.click();
        	
        	nonprimaryvpa = vpastring + "@airtel";
        	
        }
    }
    
    public static void selectVPA(String vpa) {
		WebElement allVPAsbox = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("allVPAsbox")));
		VPAlist = allVPAsbox.findElements(By.className(RunCucumberFeatures.locators.getProperty("vpaclass_vpabox")));
	
		for (int i = 0; i< VPAlist.size(); i++) {
			String vpaname = VPAlist.get(i).findElement(By.id(RunCucumberFeatures.locators.getProperty("txt_VPAtitle"))).getText().trim();
			if (vpaname.equalsIgnoreCase(vpa)) {
					VPAlist.get(i).click();
					break;
			}
		}
		
	}
    
    public static boolean isVPAPresent(String vpaval) {
		boolean presence = false;
		
		WebElement allVPAsbox = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("allVPAsbox")));
		VPAlist = allVPAsbox.findElements(By.className(RunCucumberFeatures.locators.getProperty("vpaclass_vpabox")));
		for (int i = 0; i< VPAlist.size(); i++) {
			String vpaname = VPAlist.get(i).findElement(By.id(RunCucumberFeatures.locators.getProperty("txt_VPAtitle"))).getText().trim();
			if (vpaname.equalsIgnoreCase(vpaval)) {
				presence = true;
			}
		}
		
		return presence;
	}

}

