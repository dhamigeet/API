package com.UPIApp.cucumber.steps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.UPIApp.TestUtils.DBConnection;
import com.UPIApp.TestUtils.DriverManager;
import com.UPIApp.cucumber.tests.RunCucumberFeatures;

public class UPIRequestMoneySteps extends BaseSteps {
	
	public static String vpa_nobankaccount, vpa_bankaccount = null;
	List <WebElement> allvpas = null;
    
    @And("^I click on Change VPA$")
    public void iAmAbleToClickChangeVPA() throws Throwable {
    	WebElement lnk_changevpa = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_changevpa")));
    	lnk_changevpa.click();
    }
    
    @And("^I click on VPA tab$")
    public void iAmAbleToClickRequestMoneyVPA() throws Throwable {
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("requestmoneytabs")));
    	WebElement requestmoneytabs = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("requestmoneytabs")));
		WebElement VPAtab = requestmoneytabs.findElement(By.xpath(RunCucumberFeatures.locators.getProperty("VPAtab")));
		VPAtab.click();
    }
    
    @SuppressWarnings("unchecked")
	@Then("^I should see Change VPA title with VPA list$")
    public void iShouldSeeVPAList() throws Throwable {
    	waitForElement(By.xpath(RunCucumberFeatures.locators.getProperty("title_changeVPA")));
    	WebElement changevpalink = DriverManager.getDriver().findElement(By.xpath(RunCucumberFeatures.locators.getProperty("title_changeVPA")));
    	assertTrue(changevpalink.isDisplayed());
    	
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("vpalistbox")));
    	WebElement allvpasbox = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("vpalistbox")));
    	assertTrue(allvpasbox.isDisplayed());
    	
    	allvpas = (List<WebElement>) DriverManager.getDriver().findElements(By.id(RunCucumberFeatures.locators.getProperty("allvpas")));
    	
    	assertTrue(allvpas.size() > 0);
    }
    
    @And("^I fill vpa$")
    public void iAmAbleToFillVPA() throws Throwable {
		String vpastring = randomVPAGeneratorWithHandler(8);    	
		WebElement txtbox_reqmoneyvpa = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_reqmoneyvpa")));
		txtbox_reqmoneyvpa.clear();
		txtbox_reqmoneyvpa.sendKeys(vpastring);
    }
    
    @And("^I fill \"([^\"]*)\" as vpa$")
    public void iAmAbleToFillVPA(String vpa) throws Throwable {  	
    	WebElement txtbox_reqmoneyvpa = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_reqmoneyvpa")));
    	txtbox_reqmoneyvpa.clear();
    	txtbox_reqmoneyvpa.sendKeys(vpa);
    }
    
    @And("^I fill vpa as deleted VPA$")
    public void iAmAbleToFillDeletedVPA() throws Throwable {  	
    	String deletedvpa_query = "select VPA from UPI_VPA where STATUS = 'INACTIVE'";
    	String deletedvpa = DBConnection.getValueFromDB(configProperty.getProperty("dburl"), configProperty.getProperty("dbusrname"), configProperty.getProperty("dbusrpwd"), deletedvpa_query);
    	
    	WebElement txtbox_reqmoneyvpa = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_reqmoneyvpa")));
    	txtbox_reqmoneyvpa.clear();
    	txtbox_reqmoneyvpa.sendKeys(deletedvpa);
    }
    
    @Then("^I should see cross icon to delete the entered vpa$")
    public void iShouldSeeCrossIconOnVPAField() throws Throwable {
    	WebElement vpacrossimg = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("btn_vpacrossimg")));
    	assertTrue(vpacrossimg.isDisplayed());
    }
    
    @Then("^I should see entered text cleared after click on cross icon$")
    public void iAmAbleToClearVPA() throws Throwable {
    	WebElement vpacrossimg = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("btn_vpacrossimg")));
    	vpacrossimg.click();
    	
    	int txtlength = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_reqmoneyvpa"))).getText().trim().length();
    	assertEquals(txtlength, 0);
    }
    
    @And("^I fill \"([^\"]*)\" as remarks$")
    public void iAmAbleToFillRemarks(String remarks) throws Throwable {
    	WebElement txtbox_remarks = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_remarks")));
    	txtbox_remarks.clear();
    	txtbox_remarks.sendKeys(remarks);
    }
    
    @And("^I click on Proceed button$")
    public void iAmAbleToClickProceedButton() throws Throwable {
    	WebElement btn_proceed = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("btn_proceed")));
    	btn_proceed.click();
    }
    
    @And("^I clear the default text from Remarks field$")
    public void iAmAbleToClearRemarksDefaultText() throws Throwable {
    	WebElement txtbox_remarks = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_remarks")));
    	txtbox_remarks.clear();
    }
    
    @Then("^I should see \"([^\"]*)\" as Default Remarks text$")
    public void iShouldSeeRemarksField(String text) throws Throwable {
    	String msg = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_remarks"))).getText().trim();
    	assertEquals(msg, text);
    }
    
    @Then("^I should see Request Money Screen$")
    public void iShouldSeeRequestMoneyScreen() throws Throwable {
    	waitForElement(By.xpath(RunCucumberFeatures.locators.getProperty("txt_requestmoney")));
    	WebElement requestmoneytitle = DriverManager.getDriver().findElement(By.xpath(RunCucumberFeatures.locators.getProperty("txt_requestmoney")));
    	assertTrue(requestmoneytitle.isDisplayed());
    }
    
    @Then("^I should see VPA fields$")
    public void iShouldSeeRequestMoneyVPAScreen() throws Throwable {
    	WebElement vpabox = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("vpabox")));
    	assertTrue(vpabox.isDisplayed());
    	
    	WebElement datefield = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_date")));
    	assertTrue(datefield.isDisplayed());
    	
    	WebElement remarksfield = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_remarks")));
    	assertTrue(remarksfield.isDisplayed());
    	
    	WebElement btnproceed = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("btn_proceed")));
    	assertTrue(btnproceed.isDisplayed());
    }
    
    @Then("^I should see Primary VPA selected by default$")
    public void iShouldSeePrimaryVPASelected() throws Throwable {
    	String primaryvpa = UPIHomeScreenSteps.primaryvpatitle;
    	
    	WebElement primaryvpabox = getVPABox(primaryvpa);
    	WebElement getDefaultCheckPrimaryVPA = primaryvpabox.findElement(By.id(RunCucumberFeatures.locators.getProperty("primaryvpacheckimg")));
    	assertTrue(getDefaultCheckPrimaryVPA.isDisplayed());

    }
    
    @And("^I create VPA with no bank account linked$")
    public void iAmAbleToCreateVPANoBankAccount() throws Throwable {
    	WebElement lnk_createnewVPA = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_createnewVPA")));
        lnk_createnewVPA.click();
        
        vpa_nobankaccount = randomVPAGenerator(8);    	
		WebElement txtbox_createvpa = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_createvpa")));
    	txtbox_createvpa.clear();
    	txtbox_createvpa.sendKeys(vpa_nobankaccount);
    	DriverManager.getDriver().hideKeyboard();
    	
    	WebElement btn_vpasetup = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("btn_vpasetup")));
    	btn_vpasetup.click();
    	
    	waitForElement(By.xpath(RunCucumberFeatures.locators.getProperty("title_choosebank")));
    	WebElement screenback = DriverManager.getDriver().findElement(By.className(RunCucumberFeatures.locators.getProperty("lnk_back")));
    	screenback.click();
    	
    	waitForElement(By.xpath(RunCucumberFeatures.locators.getProperty("title_bhimupi")));
    }
    
    @And("^I select VPA with No Bank Account linked for Change VPA$")
    public void iAmAbleToSelectVPA() throws Throwable {
    	String vpa = vpa_nobankaccount + "@airtel";
    	getVPABox(vpa).click();
    }
    
    @And("^I fill Bank Account Linked VPA for request money$")
    public void iAmAbleToFillVPABankAccountLink() throws Throwable {
    	
    	String vpa_bankaccountquery = "select VPA from UPI_VPA t1 INNER JOIN UPI_VPA_ACCOUNT t2 ON t1.VPA_ID = t2.VPA_ID where t1.STATUS = 'ACTIVE'";
    	vpa_bankaccount = DBConnection.getValueFromDB(configProperty.getProperty("dburl"), configProperty.getProperty("dbusrname"), configProperty.getProperty("dbusrpwd"), vpa_bankaccountquery);
    	
    	WebElement txtbox_reqmoneyvpa = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_reqmoneyvpa")));
    	txtbox_reqmoneyvpa.sendKeys(vpa_bankaccount);
    }
    
    @And("^I am able to get Bank Account Linked VPA for Change VPA$")
    public void iAmAbleToSelectVPABankAccountLink() throws Throwable {
    	
    	String vpa_bankaccountquery = "select distinct VPA from UPI_VPA t1 INNER JOIN UPI_VPA_ACCOUNT t2 ON t1.VPA_ID = t2.VPA_ID where CUSTOMER_ID = '"+ LoginSteps.custID +"'";
    	vpa_bankaccount = DBConnection.getValueFromDB(configProperty.getProperty("dburl"), configProperty.getProperty("dbusrname"), configProperty.getProperty("dbusrpwd"), vpa_bankaccountquery);
    	
    	WebElement allvpasbox = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("vpalistbox")));
    	assertTrue(allvpasbox.isDisplayed());
    	
    	isVPAPresentForRequestMoney(vpa_bankaccount);
    	
    	getVPABox(vpa_bankaccount).click();
 
    }
    
    @And("^I should see collect money request in Pending Transactions$")
    public void iAmAbleToSeePendingTxn() throws Throwable {
    	
    	WebElement lnk_pendingtxns = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_pendingtxns")));
		lnk_pendingtxns.click();
		
		//Code to verify the txn
 
    }
    
    public WebElement getVPABox(String vpatitle) {
		WebElement vpabox = null;
		waitForElement(By.id(RunCucumberFeatures.locators.getProperty("vpalistbox")));
		
		WebElement vpalistbox = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("vpalistbox")));
		List <WebElement> allvpas = vpalistbox.findElements(By.id(RunCucumberFeatures.locators.getProperty("allvpas")));
		for(int i = 0 ; i < allvpas.size() ; i ++) {
			String vpaval = allvpas.get(i).findElement(By.id(RunCucumberFeatures.locators.getProperty("vpaname"))).getText().trim();
			if (vpaval.equalsIgnoreCase(vpatitle)) {
				vpabox = allvpas.get(i);
				break;
			}
		}
				
		return vpabox;
	}
    
    public static boolean isVPAPresentForRequestMoney(String vpaval) {
		boolean presence = false;
		
		WebElement allVPAsbox = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("vpalistbox")));
		List <WebElement> VPAlist = allVPAsbox.findElements(By.id(RunCucumberFeatures.locators.getProperty("allvpas")));
		for (int i = 0; i< VPAlist.size(); i++) {
			String vpaname = VPAlist.get(i).findElement(By.id(RunCucumberFeatures.locators.getProperty("vpaname"))).getText().trim();
			if (vpaname.equalsIgnoreCase(vpaval)) {
				presence = true;
			}
		}
		
		return presence;
	}
    
}

