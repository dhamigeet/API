package com.UPIApp.cucumber.steps;

import cucumber.api.java.en.Then;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.UPIApp.TestUtils.DriverManager;
import com.UPIApp.cucumber.tests.RunCucumberFeatures;

public class CheckBalanceScreenSteps extends BaseSteps {
    
    @Then("^I should see Account Balance$")
    public void iShouldSeeAccountBalance() {
    	waitForElement(By.xpath(RunCucumberFeatures.locators.getProperty("txt_balancePageTitle")));
    	WebElement img_banklogo = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("img_banklogo")));
    	assertTrue(img_banklogo.isDisplayed());
    	
    	WebElement txt_accountnum = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txt_accountnum")));
    	assertTrue(txt_accountnum.isDisplayed());
    	
    	WebElement txt_bankname = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txt_bankname")));
    	assertTrue(txt_bankname.isDisplayed());
    	
    	WebElement txt_balanceText = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txt_balanceText")));
    	assertEquals(txt_balanceText.getText(),"A/C Balance");
    	
    	WebElement txt_balanceAmount = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txt_balanceAmount")));
    	assertTrue(txt_balanceAmount.isDisplayed());	
        
    }

}

