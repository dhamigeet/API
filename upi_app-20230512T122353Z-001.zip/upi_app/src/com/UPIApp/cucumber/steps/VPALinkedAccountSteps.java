package com.UPIApp.cucumber.steps;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.UPIApp.TestUtils.DBConnection;
import com.UPIApp.TestUtils.DriverManager;
import com.UPIApp.cucumber.tests.RunCucumberFeatures;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class VPALinkedAccountSteps extends BaseSteps {

    public static List<WebElement> VPAlinkedaccounts = null;
    public WebElement nondefaultlinkedaccount, defaultlinkedaccount = null;
    public UPIRegistrationSteps upireg = new UPIRegistrationSteps();

    @And("^I click on Delete VPA link$")
    public void iClickVPADelete() {
        waitForElement(By.xpath(
                RunCucumberFeatures.locators.getProperty("lnk_deletevpa")));
        WebElement lnk_deletevpa = DriverManager.getDriver().findElement(By
                .id(RunCucumberFeatures.locators.getProperty("lnk_vpadelete")));
        lnk_deletevpa.click();

    }

    @And("^I click on Make Default link$")
    public void iClickMakeDefaultLink() {
        waitForElement(By.className(RunCucumberFeatures.locators
                .getProperty("linkedaccountoptionsmenu")));
        WebElement optionsmenu = DriverManager.getDriver()
                .findElement(By.className(RunCucumberFeatures.locators
                        .getProperty("linkedaccountoptionsmenu")));
        assertTrue(optionsmenu.isDisplayed());

        WebElement lnk_makedefault = DriverManager.getDriver()
                .findElement(By.xpath(RunCucumberFeatures.locators
                        .getProperty("lnk_makedefault")));
        lnk_makedefault.click();

    }

    @And("^I click on Unlink Account link$")
    public void iClickUnlinkAccountLink() {
        waitForElement(By.className(RunCucumberFeatures.locators
                .getProperty("linkedaccountoptionsmenu")));
        WebElement optionsmenu = DriverManager.getDriver()
                .findElement(By.className(RunCucumberFeatures.locators
                        .getProperty("linkedaccountoptionsmenu")));
        assertTrue(optionsmenu.isDisplayed());

        WebElement lnk_unlinkaccount = DriverManager.getDriver()
                .findElement(By.xpath(RunCucumberFeatures.locators
                        .getProperty("lnk_unlinkaccount")));
        lnk_unlinkaccount.click();

    }

    @And("^I click on Account Info link$")
    public void iClickAccountInfoLink() {
        waitForElement(By.className(RunCucumberFeatures.locators
                .getProperty("linkedaccountoptionsmenu")));
        WebElement optionsmenu = DriverManager.getDriver()
                .findElement(By.className(RunCucumberFeatures.locators
                        .getProperty("linkedaccountoptionsmenu")));
        assertTrue(optionsmenu.isDisplayed());

        WebElement lnk_accountinfo = DriverManager.getDriver()
                .findElement(By.xpath(RunCucumberFeatures.locators
                        .getProperty("lnk_accountinfo")));
        lnk_accountinfo.click();

    }

    @And("^I click on Check Balance link$")
    public void iClickCheckBalanceLink() {
        waitForElement(By.className(RunCucumberFeatures.locators
                .getProperty("linkedaccountoptionsmenu")));
        WebElement optionsmenu = DriverManager.getDriver()
                .findElement(By.className(RunCucumberFeatures.locators
                        .getProperty("linkedaccountoptionsmenu")));
        assertTrue(optionsmenu.isDisplayed());

        WebElement lnk_accountinfo = DriverManager.getDriver()
                .findElement(By.xpath(RunCucumberFeatures.locators
                        .getProperty("txt_checkBalance")));
        lnk_accountinfo.click();

    }

    @And("^I click on Change MPIN link$")
    public void iClickChangeMpinLink() throws InterruptedException {
        waitForElement(By.className(RunCucumberFeatures.locators
                .getProperty("linkedaccountoptionsmenu")));
        WebElement optionsmenu = DriverManager.getDriver()
                .findElement(By.className(RunCucumberFeatures.locators
                        .getProperty("linkedaccountoptionsmenu")));
        assertTrue(optionsmenu.isDisplayed());

        WebElement lnk_accountinfo = DriverManager.getDriver()
                .findElement(By.xpath(RunCucumberFeatures.locators
                        .getProperty("txt_changeMPIN")));
        lnk_accountinfo.click();

        Thread.sleep(5000);

    }

    @And("^I click on Link More Accounts button$")
    public void iClickLinkMoreAccountsButton() throws Exception {
        waitForElement(By.id(RunCucumberFeatures.locators
                .getProperty("btn_linkmoreaccounts")));
        WebElement btn_linkmoreaccounts = DriverManager.getDriver()
                .findElement(By.id(RunCucumberFeatures.locators
                        .getProperty("btn_linkmoreaccounts")));
        assertTrue(btn_linkmoreaccounts.isDisplayed());

        Thread.sleep(2000);

        btn_linkmoreaccounts.click();

    }

    @Then("^I should see Delete VPA$")
    public void iShouldSeeDeleteVPA() throws Throwable {
        WebElement screenheader = DriverManager.getDriver().findElement(By
                .id(RunCucumberFeatures.locators.getProperty("screenheader")));
        WebElement lnk_vpaoptions = screenheader.findElement(By.className(
                RunCucumberFeatures.locators.getProperty("lnk_vpaoptions")));
        assertTrue(lnk_vpaoptions.isDisplayed());
        lnk_vpaoptions.click();
        waitForElement(By
                .id(RunCucumberFeatures.locators.getProperty("lnk_vpadelete")));
        WebElement deletevpalink = DriverManager.getDriver().findElement(By
                .id(RunCucumberFeatures.locators.getProperty("lnk_vpadelete")));
        assertTrue(deletevpalink.isDisplayed());
    }

    @Then("^I should see Linked Non Primary Account with VPAs$")
    public void iShouldSeeLinkedAccounts() throws Throwable {
        int i;
        String ACCOUNTID_query = "SELECT MASKED_ACCOUNT_NUMBER FROM UPI_ACCOUNT WHERE STATUS ='ACTIVE' AND CUSTOMER_ID='"
                + LoginSteps.custID
                + "' AND ACCOUNT_ID NOT IN (SELECT PRIMARY_ACCOUNT_ID FROM UPI_VPA WHERE STATUS ='ACTIVE' AND CUSTOMER_ID='"
                + LoginSteps.custID + "')";
        String ACCOUNT_ID = DBConnection.getValueFromDB(
                configProperty.getProperty("dburl"),
                configProperty.getProperty("dbusrname"),
                configProperty.getProperty("dbusrpwd"), ACCOUNTID_query);

        waitForElement(By.xpath(RunCucumberFeatures.locators
                .getProperty("txt_linkedaccounts")));

        waitForElement(By.id(
                RunCucumberFeatures.locators.getProperty("accountcontainer")));
        WebElement accountsbox = DriverManager.getDriver().findElement(By.id(
                RunCucumberFeatures.locators.getProperty("accountcontainer")));
        assertTrue(accountsbox.isDisplayed());

        VPAlinkedaccounts = accountsbox
                .findElements(By.className(RunCucumberFeatures.locators
                        .getProperty("linkedaccounts_class")));

        List<WebElement> alllinkedaccs = accountsbox
                .findElements(By.className(RunCucumberFeatures.locators
                        .getProperty("linkedaccounts_class")));
        for (i = 0; i < alllinkedaccs.size(); i++) {
            WebElement accountId = DriverManager.getDriver().findElement(By.id(
                    RunCucumberFeatures.locators.getProperty("txt_acountNum")));
            if (accountId.getText().equals(ACCOUNT_ID)) {
                break;
            }
        }

        defaultlinkedaccount = alllinkedaccs.get(i);
        WebElement linkedaccountoptions = defaultlinkedaccount
                .findElement(By.id(RunCucumberFeatures.locators
                        .getProperty("linkedaccountoptions")));
        assertTrue(linkedaccountoptions.isDisplayed());
        linkedaccountoptions.click();
    }

    @Then("^I should see Default Linked Account with Option button$")
    public void iShouldSeeDefaultLinkedAccountOptions() throws Throwable {
        int i;
        waitForElement(By.xpath(RunCucumberFeatures.locators
                .getProperty("txt_linkedaccounts")));

        waitForElement(By.id(
                RunCucumberFeatures.locators.getProperty("accountcontainer")));
        WebElement accountsbox = DriverManager.getDriver().findElement(By.id(
                RunCucumberFeatures.locators.getProperty("accountcontainer")));
        assertTrue(accountsbox.isDisplayed());

        List<WebElement> alllinkedaccs = accountsbox
                .findElements(By.className(RunCucumberFeatures.locators
                        .getProperty("linkedaccounts_class")));
        for (i = 0; i < alllinkedaccs.size(); i++) {
            WebElement defaultacclink = alllinkedaccs.get(i)
                    .findElement(By.id(RunCucumberFeatures.locators
                            .getProperty("defaultlinkaccountimg")));
            if (defaultacclink.isDisplayed()) {
                break;
            }
        }
        defaultlinkedaccount = alllinkedaccs.get(i);
        WebElement linkedaccountoptions = defaultlinkedaccount
                .findElement(By.id(RunCucumberFeatures.locators
                        .getProperty("linkedaccountoptions")));
        assertTrue(linkedaccountoptions.isDisplayed());
        linkedaccountoptions.click();
    }

    @Then("^I should see Non Default Linked Account with bank as \"([^\"]*)\" with Option button$")
    public void iShouldSeeNonDefaultLinkedAccountOptions(String bankname)
            throws Throwable {
        waitForElement(By.xpath(RunCucumberFeatures.locators
                .getProperty("txt_linkedaccounts")));

        waitForElement(By.id(
                RunCucumberFeatures.locators.getProperty("accountcontainer")));
        WebElement accountsbox = DriverManager.getDriver().findElement(By.id(
                RunCucumberFeatures.locators.getProperty("accountcontainer")));
        assertTrue(accountsbox.isDisplayed());

        VPAlinkedaccounts = accountsbox
                .findElements(By.className(RunCucumberFeatures.locators
                        .getProperty("linkedaccounts_class")));
        WebElement defaultcheckimg = DriverManager.getDriver()
                .findElement(By.id(RunCucumberFeatures.locators
                        .getProperty("defaultlinkaccountimg")));

        if ((VPAlinkedaccounts.size() == 1) && defaultcheckimg.isDisplayed()) {

            WebElement btn_linkmoreaccounts = DriverManager.getDriver()
                    .findElement(By.id(RunCucumberFeatures.locators
                            .getProperty("btn_linkmoreaccounts")));
            btn_linkmoreaccounts.click();

            waitForElement(By.xpath(RunCucumberFeatures.locators
                    .getProperty("title_choosebank")));
            waitForElement(By.id(RunCucumberFeatures.locators
                    .getProperty("txtbox_srchbank")));
            VPACreationSteps.selectBank(bankname);

            waitForElement(By.id(RunCucumberFeatures.locators
                    .getProperty("bankaccountspopup")));
            waitForElement(By.id(RunCucumberFeatures.locators
                    .getProperty("accountcontainer")));
            VPACreationSteps.selectBankAccount(bankname);
            upireg.iAmAbleToClickDone();

        }

        waitForElement(By.xpath(RunCucumberFeatures.locators
                .getProperty("txt_linkedaccounts")));
        WebElement allaccountsbox = DriverManager.getDriver().findElement(By.id(
                RunCucumberFeatures.locators.getProperty("accountcontainer")));
        VPAlinkedaccounts = allaccountsbox
                .findElements(By.className(RunCucumberFeatures.locators
                        .getProperty("linkedaccounts_class")));
        nondefaultlinkedaccount = VPAlinkedaccounts.get(1);
        WebElement nondefaultlinkedaccountoptions = nondefaultlinkedaccount
                .findElement(By.id(RunCucumberFeatures.locators
                        .getProperty("linkedaccountoptions")));
        assertTrue(nondefaultlinkedaccountoptions.isDisplayed());
        nondefaultlinkedaccountoptions.click();
    }

    @Then("^I should see options as \"([^\"]*)\"$")
    public void iShouldSeeOptions(String options) throws Throwable {
        String[] menuitems = options.split(", ");
        List<String> menuItemsList = Arrays.asList(menuitems);
        Collections.sort(menuItemsList);

        ArrayList<String> optionslist = getLinkedAccountMenu();
        Collections.sort(optionslist);

        assertEquals(optionslist, menuItemsList);

    }

    @Then("^I should not see removed Non Default linked account$")
    public void iShouldNotSeeLinkedAccount() throws Throwable {
        boolean result = true;

        waitForElement(By.xpath(RunCucumberFeatures.locators
                .getProperty("txt_linkedaccounts")));
        try {
            if (nondefaultlinkedaccount.isDisplayed()) {

            }
        } catch (Exception e) {
            result = false;
        }

        assertEquals(result, false);
    }

    @Then("^I should see popup with \"([^\"]*)\" and click OK for confirmation$")
    public void iShouldSeePopUpMsg(String msg) throws Throwable {
        waitForElement(
                By.id(RunCucumberFeatures.locators.getProperty("dialogbox")));

        WebElement confirmpopup = DriverManager.getDriver().findElement(
                By.id(RunCucumberFeatures.locators.getProperty("dialogbox")));
        assertTrue(confirmpopup.isDisplayed());

        String ui_msg = DriverManager.getDriver()
                .findElement(By.id(
                        RunCucumberFeatures.locators.getProperty("dialogmsg")))
                .getText().trim();
        assertEquals(ui_msg, msg);

        WebElement btn_dialogOK = DriverManager.getDriver().findElement(By
                .id(RunCucumberFeatures.locators.getProperty("btn_dialogOK")));
        btn_dialogOK.click();
    }

    @Then("^I should see change in selection with message as \"([^\"]*)\" and options menu disappear$")
    public void iShouldSeeMakeDefaultVPA(String msg) {
        boolean result = true;

        waitForElement(By.xpath(RunCucumberFeatures.locators
                .getProperty("txt_linkedaccounts")));
        WebElement newlinkaccount_default = nondefaultlinkedaccount
                .findElement(By.id(RunCucumberFeatures.locators
                        .getProperty("defaultlinkaccountimg")));
        assertTrue(newlinkaccount_default.isDisplayed());

        try {
            defaultlinkedaccount.findElement(By.id(RunCucumberFeatures.locators
                    .getProperty("defaultlinkaccountimg")));

        } catch (Exception e) {
            result = false;
        }

        assertEquals(result, false);
        String bankname = nondefaultlinkedaccount.findElement(By
                .id(RunCucumberFeatures.locators.getProperty("linkedbankname")))
                .getText().trim();
        String accountnumber = nondefaultlinkedaccount.findElement(By.id(
                RunCucumberFeatures.locators.getProperty("linkedaccnumber")))
                .getText().trim();

        if (bankname.isEmpty()) {
            bankname = "";
        }

        String expectedmsg = bankname + "( " + accountnumber + " )" + " " + msg;
        String text = getFooterMsg();
        assertEquals(expectedmsg, text);
    }

    @Then("^I should see Primary Label with \"([^\"]*)\"$")
    public void iShouldSeePrimaryLabel(String text) throws Throwable {

        try {
            waitForElement(By
                    .id(RunCucumberFeatures.locators.getProperty("footermsg")));
            WebElement footermsg = DriverManager.getDriver().findElement(By
                    .id(RunCucumberFeatures.locators.getProperty("footermsg")));
            if (footermsg.isDisplayed()) {
                String msg = getFooterMsg();
                assertEquals(msg, text);
            }

        } catch (Exception e) {
            waitForElement(By.xpath(
                    RunCucumberFeatures.locators.getProperty("label_primary")));
            WebElement label_primary = DriverManager.getDriver()
                    .findElement(By.xpath(RunCucumberFeatures.locators
                            .getProperty("label_primary")));
            assertTrue(label_primary.isDisplayed());
        }

    }

    @Then("^I should see Primary Label$")
    public void iShouldSeePrimaryLabel() throws Throwable {
        waitForElement(By.xpath(
                RunCucumberFeatures.locators.getProperty("label_primary")));
        WebElement label_primary = DriverManager.getDriver()
                .findElement(By.xpath(RunCucumberFeatures.locators
                        .getProperty("label_primary")));
        assertTrue(label_primary.isDisplayed());

    }

    @And("^I click on VPA for Primary Label$")
    public void iClickVPAForPrimaryLabel() throws Throwable {
        if (MoreVPAsSteps.VPAlist.size() == 1) {
            WebElement screenheader = DriverManager.getDriver()
                    .findElement(By.id(RunCucumberFeatures.locators
                            .getProperty("screenheader")));
            WebElement lnk_back = screenheader.findElement(By.className(
                    RunCucumberFeatures.locators.getProperty("lnk_back")));
            lnk_back.click();

            WebElement lnk_createnewVPA = DriverManager.getDriver()
                    .findElement(By.id(RunCucumberFeatures.locators
                            .getProperty("lnk_createnewVPA")));
            lnk_createnewVPA.click();

            String vpastring = randomVPAGenerator(8);
            WebElement txtbox_createvpa = DriverManager.getDriver()
                    .findElement(By.id(RunCucumberFeatures.locators
                            .getProperty("txtbox_createvpa")));
            txtbox_createvpa.clear();
            txtbox_createvpa.sendKeys(vpastring);
            DriverManager.getDriver().hideKeyboard();

            WebElement btn_vpasetup = DriverManager.getDriver()
                    .findElement(By.id(RunCucumberFeatures.locators
                            .getProperty("btn_vpasetup")));
            btn_vpasetup.click();

            waitForElement(By.xpath(RunCucumberFeatures.locators
                    .getProperty("title_choosebank")));
            lnk_back.click();

            waitForElement(By.id(
                    RunCucumberFeatures.locators.getProperty("lnk_moreVPAs")));
            WebElement lnk_moreVPAs = DriverManager.getDriver()
                    .findElement(By.id(RunCucumberFeatures.locators
                            .getProperty("lnk_moreVPAs")));
            lnk_moreVPAs.click();
        }

        String vpa = UPIHomeScreenSteps.primaryvpatitle;
        MoreVPAsSteps.selectVPA(vpa);
    }

    @Then("^I should see Make Primary Label$")
    public void iShouldSeeMakePrimaryLabel() throws Throwable {
        waitForElement(By.xpath(
                RunCucumberFeatures.locators.getProperty("label_makeprimary")));
        WebElement label_makeprimary = DriverManager.getDriver()
                .findElement(By.xpath(RunCucumberFeatures.locators
                        .getProperty("label_makeprimary")));
        assertTrue(label_makeprimary.isDisplayed());

    }

    @And("^I click on Make Primary Label$")
    public void iAmAbleToClickMakePrimaryLabel() throws Throwable {
        waitForElement(By.xpath(
                RunCucumberFeatures.locators.getProperty("label_makeprimary")));
        WebElement label_makeprimary = DriverManager.getDriver()
                .findElement(By.xpath(RunCucumberFeatures.locators
                        .getProperty("label_makeprimary")));
        label_makeprimary.click();

    }

    @And("^I click on Primary Label$")
    public void iAmAbleToClickPrimaryLabel() throws Throwable {
        WebElement label_primary = DriverManager.getDriver()
                .findElement(By.xpath(RunCucumberFeatures.locators
                        .getProperty("label_primary")));
        label_primary.click();
    }

    @And("^I go back to previous Screen$")
    public void iAmAbleToGoBack() throws Throwable {
        WebElement screenheader = DriverManager.getDriver().findElement(By
                .id(RunCucumberFeatures.locators.getProperty("screenheader")));
        WebElement lnk_back = screenheader.findElement(By.className(
                RunCucumberFeatures.locators.getProperty("lnk_back")));
        lnk_back.click();
    }

    @Then("^I should see \"([^\"]*)\" as unlink account message$")
    public void iShouldSeeMessage(String msg) {
        waitForElement(
                By.id(RunCucumberFeatures.locators.getProperty("footermsg")));
        String uimsg = getFooterMsg().trim();
        String txt[] = uimsg.split("with number");
        String ui_txt = txt[1].trim().substring(10);

        String actualmsg = txt[0].trim() + ui_txt;
        assertEquals(actualmsg, msg);
    }

    @Then("^I should see success \"([^\"]*)\"$")
    public void iShouldSeeSuccessMessage(String msg) {
        waitForElement(
                By.id(RunCucumberFeatures.locators.getProperty("txt_linkAcc")));
        WebElement label_makeprimary = DriverManager.getDriver().findElement(
                By.id(RunCucumberFeatures.locators.getProperty("txt_linkAcc")));
        assertEquals(label_makeprimary.getText(), msg);
    }

    @Then("^I should see \"([^\"]*)\" Linked Account$")
    public void iShouldSeeExternalLinkedAccount(String bankName)
            throws Throwable {
        int i;
        waitForElement(By.xpath(RunCucumberFeatures.locators
                .getProperty("txt_linkedaccounts")));

        waitForElement(By.id(
                RunCucumberFeatures.locators.getProperty("accountcontainer")));
        WebElement accountsbox = DriverManager.getDriver().findElement(By.id(
                RunCucumberFeatures.locators.getProperty("accountcontainer")));
        assertTrue(accountsbox.isDisplayed());
        List<WebElement> alllinkedaccs = accountsbox
                .findElements(By.className(RunCucumberFeatures.locators
                        .getProperty("linkedaccounts_class")));

        for (i = 0; i < alllinkedaccs.size(); i++) {

            WebElement defaultacclink = alllinkedaccs.get(i).findElement(
                    By.id(RunCucumberFeatures.locators.getProperty("b_name")));
            System.out.println(defaultacclink.getText());
            if (defaultacclink.getText().equals(bankName)) {
                break;
            }
        }
        defaultlinkedaccount = alllinkedaccs.get(i);
        WebElement linkedaccountoptions = defaultlinkedaccount
                .findElement(By.id(RunCucumberFeatures.locators
                        .getProperty("linkedaccountoptions")));
        assertTrue(linkedaccountoptions.isDisplayed());
        linkedaccountoptions.click();
    }

    public ArrayList<String> getLinkedAccountMenu() {
        ArrayList<String> optionslist = new ArrayList<String>();

        waitForElement(By.className(RunCucumberFeatures.locators
                .getProperty("linkedaccountoptionsmenu")));

        WebElement linkedaccoptionsmenu = DriverManager.getDriver()
                .findElement(By.className(RunCucumberFeatures.locators
                        .getProperty("linkedaccountoptionsmenu")));
        assertTrue(linkedaccoptionsmenu.isDisplayed());

        List<WebElement> menuitems = linkedaccoptionsmenu
                .findElements(By.className(RunCucumberFeatures.locators
                        .getProperty("optionsmenuitems")));
        for (int i = 0; i < menuitems.size(); i++) {
            String title = menuitems.get(i)
                    .findElement(By.id(RunCucumberFeatures.locators
                            .getProperty("optionsmenutitle")))
                    .getText().trim();
            optionslist.add(title);
        }

        return optionslist;
    }

}
