package com.UPIApp.cucumber.steps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.UPIApp.TestUtils.DriverManager;
import com.UPIApp.cucumber.tests.RunCucumberFeatures;

public class AmountSteps extends BaseSteps {
	
	public static String reqmoneydate = null;
	   
    @Then("^I should see Amount screen$")
    public void iShouldSeeAmountScreen() throws Throwable {
    	waitForElement(By.xpath(RunCucumberFeatures.locators.getProperty("title_entereamount")));
    	WebElement amountscreentitle = DriverManager.getDriver().findElement(By.xpath(RunCucumberFeatures.locators.getProperty("title_entereamount")));
    	assertTrue(amountscreentitle.isDisplayed());
    }
    
    @And("^I fill \"([^\"]*)\" as amount$")
    public void iAmAbleToFillAmount(String amt) throws Throwable {
    	fillKeypadValue(amt);
    	clickDialOK();
    	
    	SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy hh:mm aa");
    	Date date = new Date();  
        reqmoneydate =  formatter.format(date);
    }
    
    @Then("^I should see \"([^\"]*)\" as amount limit message with \"([^\"]*)\"$")
    public void iShouldSeeAmountLimitMessage(String msg, String amt) throws IOException {
    	if (amt.equalsIgnoreCase("0")) {  	    
    		String text = getFooterMsg();
    		text = text.substring(0, text.length() - 2) + "0";
    		assertEquals(text, msg);
    		
    	}else {
    		
    		assertEquals(getFooterMsg(), msg);
    	}
    	
    }
    
}

