package com.UPIApp.cucumber.steps;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.ServerSocket;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.UPIApp.TestUtils.DriverFactory;
import com.UPIApp.TestUtils.DriverManager;
import com.UPIApp.cucumber.tests.RunCucumberFeatures;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import io.appium.java_client.service.local.flags.GeneralServerFlag;

public class BaseSteps {

    public WebDriverWait wait;
    public AndroidDriver<?> driver;
    public static Properties configProperty;
    public static AppiumDriverLocalService service;
    public static AppiumServiceBuilder builder;
    public static DesiredCapabilities cap;
    private static final String ALPHA_NUMERIC_STRING = "abcdefghijklmnopqrstuvwxyz0123456789";

    public void startServer() {
        // Set Capabilities
        cap = new DesiredCapabilities();
        cap.setCapability("noReset", "false");

        // Build the Appium service
        builder = new AppiumServiceBuilder();
        builder.withIPAddress("127.0.0.1");
        builder.usingPort(4723);
        builder.withCapabilities(cap);
        builder.withArgument(GeneralServerFlag.SESSION_OVERRIDE);
        builder.withArgument(GeneralServerFlag.LOG_LEVEL, "error");

        // Start the server with the builder
        service = AppiumDriverLocalService.buildService(builder);
        service.start();
        System.out.println("Successfully started server");
    }

    public void stopServer() {
        service.stop();
    }

    public boolean checkIfServerIsRunnning(int port) {
        boolean isServerRunning = false;
        ServerSocket serverSocket;
        try {
            serverSocket = new ServerSocket(port);
            serverSocket.close();
        } catch (IOException e) {
            // If control comes here, then it means that the port is in use
            isServerRunning = true;
        } finally {
            serverSocket = null;
        }
        System.out.println("isServerRunning:" + isServerRunning);
        return isServerRunning;
    }

    public void initializeTheDriver() {

        try {
            FileInputStream config = new FileInputStream(new File(System
                    .getProperty("user.dir")
                    + "//src//com//UPIApp//resources//config.properties"));
            configProperty = new Properties();
            try {
                configProperty.load(config);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        driver = new DriverFactory().createDriverInstance(
                configProperty.getProperty("platformname"),
                configProperty.getProperty("devicename"),
                configProperty.getProperty("platformversion"),
                configProperty.getProperty("apppackage"),
                configProperty.getProperty("appactivity"));
        DriverManager.setDriver(driver);
        // DriverManager.setImplicitWait(driver);
    }

    public void waitForElement(By by) {
        WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(), 80);
        wait.until(ExpectedConditions.visibilityOfElementLocated(by));
    }

    public String getFooterMsg() {
        WebElement txtbox_createvpa = DriverManager.getDriver().findElement(
                By.id(RunCucumberFeatures.locators.getProperty("footermsg")));
        return txtbox_createvpa.getText();
    }

    public static String randomVPAGenerator(int charcount) {
        StringBuilder builder = new StringBuilder();

        while (charcount-- != 0) {
            int character = (int) (Math.random()
                    * ALPHA_NUMERIC_STRING.length());
            builder.append(ALPHA_NUMERIC_STRING.charAt(character));
        }

        String vpavalue = builder.toString();
        return vpavalue;
    }

    public static String randomVPAGeneratorWithHandler(int charcount) {
        StringBuilder builder = new StringBuilder();

        while (charcount-- != 0) {
            int character = (int) (Math.random()
                    * ALPHA_NUMERIC_STRING.length());
            builder.append(ALPHA_NUMERIC_STRING.charAt(character));
        }

        String vpavalue = builder.toString() + "@airtel";
        return vpavalue;
    }

    public void fillKeypadValue(String value) {

        String[] valarr = value.split("");
        for (int i = 0; i < valarr.length; i++) {
            int val = Integer.parseInt(valarr[i]);
            switch (val) {
            case 0:
            	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_dialno0")));
                DriverManager.getDriver()
                        .findElement(By.id(RunCucumberFeatures.locators
                                .getProperty("lnk_dialno0")))
                        .click();
                break;
            case 1:
            	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_dialno1")));
                DriverManager.getDriver()
                        .findElement(By.id(RunCucumberFeatures.locators
                                .getProperty("lnk_dialno1")))
                        .click();
                break;
            case 2:
            	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_dialno2")));
                DriverManager.getDriver()
                        .findElement(By.id(RunCucumberFeatures.locators
                                .getProperty("lnk_dialno2")))
                        .click();
                break;
            case 3:
            	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_dialno3")));
                DriverManager.getDriver()
                        .findElement(By.id(RunCucumberFeatures.locators
                                .getProperty("lnk_dialno3")))
                        .click();
                break;
            case 4:
            	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_dialno4")));
                DriverManager.getDriver()
                        .findElement(By.id(RunCucumberFeatures.locators
                                .getProperty("lnk_dialno4")))
                        .click();
                break;
            case 5:
            	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_dialno5")));
                DriverManager.getDriver()
                        .findElement(By.id(RunCucumberFeatures.locators
                                .getProperty("lnk_dialno5")))
                        .click();
                break;
            case 6:
            	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_dialno6")));
                DriverManager.getDriver()
                        .findElement(By.id(RunCucumberFeatures.locators
                                .getProperty("lnk_dialno6")))
                        .click();
                break;
            case 7:
            	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_dialno7")));
                DriverManager.getDriver()
                        .findElement(By.id(RunCucumberFeatures.locators
                                .getProperty("lnk_dialno7")))
                        .click();
                break;
            case 8:
            	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_dialno8")));
                DriverManager.getDriver()
                        .findElement(By.id(RunCucumberFeatures.locators
                                .getProperty("lnk_dialno8")))
                        .click();
                break;
            case 9:
            	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_dialno9")));
                DriverManager.getDriver()
                        .findElement(By.id(RunCucumberFeatures.locators
                                .getProperty("lnk_dialno9")))
                        .click();
                break;
            }
        }

    }

    public void fillKeypadValue2(String value) {

        String[] valarr = value.split("");
        for (int i = 0; i < valarr.length; i++) {
            int val = Integer.parseInt(valarr[i]);
            switch (val) {
            case 0:
                DriverManager.getDriver()
                        .findElement(By.xpath(RunCucumberFeatures.locators
                                .getProperty("lnk_enterno0")))
                        .click();
                break;
            case 1:
                DriverManager.getDriver()
                        .findElement(By.xpath(RunCucumberFeatures.locators
                                .getProperty("lnk_enterno1")))
                        .click();
                break;
            case 2:
                DriverManager.getDriver()
                        .findElement(By.xpath(RunCucumberFeatures.locators
                                .getProperty("lnk_enterno2")))
                        .click();
                break;
            case 3:
                DriverManager.getDriver()
                        .findElement(By.xpath(RunCucumberFeatures.locators
                                .getProperty("lnk_enterno3")))
                        .click();
                break;
            case 4:
                DriverManager.getDriver()
                        .findElement(By.xpath(RunCucumberFeatures.locators
                                .getProperty("lnk_enterno4")))
                        .click();
                break;
            case 5:
                DriverManager.getDriver()
                        .findElement(By.xpath(RunCucumberFeatures.locators
                                .getProperty("lnk_enterno5")))
                        .click();
                break;
            case 6:
                DriverManager.getDriver()
                        .findElement(By.xpath(RunCucumberFeatures.locators
                                .getProperty("lnk_enterno6")))
                        .click();
                break;
            case 7:
                DriverManager.getDriver()
                        .findElement(By.xpath(RunCucumberFeatures.locators
                                .getProperty("lnk_enterno7")))
                        .click();
                break;
            case 8:
                DriverManager.getDriver()
                        .findElement(By.xpath(RunCucumberFeatures.locators
                                .getProperty("lnk_enterno8")))
                        .click();
                break;
            case 9:
                DriverManager.getDriver()
                        .findElement(By.xpath(RunCucumberFeatures.locators
                                .getProperty("lnk_enterno9")))
                        .click();
                break;
            }
        }

    }

    public String fetchAccounttype(String mobnum) {

        String usr_type = configProperty.getProperty("upi_registration_type");
        if (usr_type.equalsIgnoreCase("SBA")) {
            mobnum = configProperty.getProperty("upi_SBA_mobnum");
        } else {
            mobnum = configProperty.getProperty("upi_LKY_mobnum");
        }
        return mobnum;
    }

    public void clickDialOK() {
        WebElement lnk_ok = DriverManager.getDriver().findElement(
                By.id(RunCucumberFeatures.locators.getProperty("lnk_ok")));
        lnk_ok.click();
    }

    public static void AppPermission(AndroidDriver<?> driver) {
        while (driver
                .findElements(
                        By.xpath("//*[@class='android.widget.Button'][2]"))
                .size() > 0) {
            driver.findElement(
                    By.xpath("//*[@class='android.widget.Button'][2]")).click();
        }

    }

    protected void teardownTheDriver() {

        try {
            DriverManager.closeDriver(DriverManager.getDriver());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
