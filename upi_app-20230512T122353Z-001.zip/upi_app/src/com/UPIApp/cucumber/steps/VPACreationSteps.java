package com.UPIApp.cucumber.steps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.UPIApp.TestUtils.DBConnection;
import com.UPIApp.TestUtils.DriverManager;
import com.UPIApp.cucumber.tests.RunCucumberFeatures;

public class VPACreationSteps extends BaseSteps {
    
    @And("^I click on create new VPA link$")
    public void iClickOnCreateVPA() {
        WebElement lnk_createnewVPA = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_createnewVPA")));
        lnk_createnewVPA.click();
        
    }
    
    @And("^I click on setup button$")
    public void iClickOnSetUp() {
    	WebElement btn_vpasetup = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("btn_vpasetup")));
    	btn_vpasetup.click();
    }
   
    
    @Then("^I should see \"([^\"]*)\" as message$")
    public void iShouldSeeMessage(String msg) {
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("footermsg")));
    	//assertEquals(getFooterMsg(), msg);
    	assertTrue(getFooterMsg().contains(msg));
    	
    }
    
    @And("^I fill \"([^\"]*)\" as VPA$")
    public void iFillVPA(String vpa) {
    	WebElement txtbox_createvpa = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_createvpa")));
    	txtbox_createvpa.clear();
    	txtbox_createvpa.sendKeys(vpa);
    	DriverManager.getDriver().hideKeyboard();
    }
    
    @And("^I fill existing vpa as VPA$")
    public void iFillVPAAsExistingVPA() throws Exception {
    	String existingvpaquery = "select VPA from UPI_VPA where STATUS = 'ACTIVE'";    	
        String existingvpa = DBConnection.getValueFromDB(configProperty.getProperty("dburl"), configProperty.getProperty("dbusrname"), configProperty.getProperty("dbusrpwd"), existingvpaquery);
    	
        String existvpaarr[] = existingvpa.split("@");
        existingvpa = existvpaarr[0].trim();
        
    	WebElement txtbox_createvpa = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_createvpa")));
    	txtbox_createvpa.clear();
    	txtbox_createvpa.sendKeys(existingvpa);
    	DriverManager.getDriver().hideKeyboard();
    }
    
    @And("^I fill deleted or closed vpa as VPA$")
    public void iFillVPAAsDeletedORClosedVPA() throws Exception {
    	String existingvpaquery = "select VPA from UPI_VPA where STATUS = 'INACTIVE'";    	
        String existingvpa = DBConnection.getValueFromDB(configProperty.getProperty("dburl"), configProperty.getProperty("dbusrname"), configProperty.getProperty("dbusrpwd"), existingvpaquery);
    	
        String existvpaarr[] = existingvpa.split("@");
        existingvpa = existvpaarr[0].trim();
        
    	WebElement txtbox_createvpa = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_createvpa")));
    	txtbox_createvpa.clear();
    	txtbox_createvpa.sendKeys(existingvpa);
    	DriverManager.getDriver().hideKeyboard();
    }
    
    @And("^I fill vpa for VPA setup$")
    public void iFillVPA() throws Throwable {
		String vpastring = randomVPAGenerator(8);    	
		WebElement txtbox_createvpa = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_createvpa")));
    	    txtbox_createvpa.clear();
       	txtbox_createvpa.sendKeys(vpastring);
    	    DriverManager.getDriver().hideKeyboard();
    }
    
    @Then("^I should see choose bank screen$")
    public void iShouldSeeChooseBankScreen() {
    	waitForElement(By.xpath(RunCucumberFeatures.locators.getProperty("title_choosebank")));
    	WebElement choosebanktitle = DriverManager.getDriver().findElement(By.xpath(RunCucumberFeatures.locators.getProperty("title_choosebank")));
    	assertTrue(choosebanktitle.isDisplayed());
    	
    	WebElement txtbox_srchbank = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_srchbank")));
    	assertTrue(txtbox_srchbank.isDisplayed());
    
    	/*
    	WebElement banklistcontainer = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("banklistcontainer")));
    	assertTrue(banklistcontainer.isDisplayed());
    	
    	List <WebElement> allbanks = banklistcontainer.findElements(By.id(RunCucumberFeatures.locators.getProperty("bankname")));
    	assertTrue(allbanks.size() > 0);
    */}
    
    @And("^I select \"([^\"]*)\" as my bank account$")
    public void iAmAbleToSelectBank_VPASetup(String bankname) {
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_srchbank")));
    	selectBank(bankname);
    	
    /*	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("bankaccountspopup")));
    	WebElement bankaccountspopup = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("bankaccountspopup")));
    	assertTrue(bankaccountspopup.isDisplayed());
    	
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("accountcontainer")));
    	WebElement allbankaccountsbox = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("accountcontainer")));
    	assertTrue(allbankaccountsbox.isDisplayed());
    	
    	selectBankAccount(bankname);  	
    */}
    
    @Then("^I enter VPA details and click on Setup button$")
    public void iEnterVpaDetails() throws Throwable {
    	String vpastring = randomVPAGenerator(8);  
    	WebElement vpafield = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_registrationvpa")));
    	vpafield.sendKeys(vpastring);
    	

    	WebElement vpasetupbutton = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("btn_vpasetup")));
    	vpasetupbutton.click();
    }
    
    @Then("^I should see the UPI Setup screen with VPA, VPA handler and Set Up fields$")
    public void iShouldSeeUPISetupFields() throws Throwable {
    	WebElement vpafield = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_registrationvpa")));
    	assertTrue(vpafield.isDisplayed());
    	
    	WebElement vpahandler = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("vpahandler")));
    	assertTrue(vpahandler.isDisplayed());

    	WebElement vpasetupbutton = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("btn_vpasetup")));
    	assertTrue(vpasetupbutton.isDisplayed());
    }
    
    public static void selectBankAccount(String bankname) {
		WebElement accountcontainer = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("accountcontainer")));
		List<WebElement> bankacclst = accountcontainer.findElements(By.id(RunCucumberFeatures.locators.getProperty("accountnumber")));
		
		if (bankname.equalsIgnoreCase("AIRTEL PAYMENTS BANK")) {
			String mob = LoginSteps.mobnum;
	    	String acclastfourdigits = mob.substring(mob.length() - 4);
	    	
			for (int i = 0; i< bankacclst.size(); i++) {
				String accnum = bankacclst.get(i).getText().trim();
				String accdigits = accnum.substring(accnum.length() - 4);
				if(accdigits.equalsIgnoreCase(acclastfourdigits)) {
					bankacclst.get(i).click();
					break;
				}	
			}
			
		}else {
			bankacclst.get(0).click();
		}
		
	}
    
    public static void selectBank(String bankname) {
    	WebElement txtbox_srchbank = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_srchbank")));
    	txtbox_srchbank.clear();
    	txtbox_srchbank.sendKeys(bankname);
		WebElement banklistcontainer = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("banklistcontainer")));
		
		List<WebElement> banklst = banklistcontainer.findElements(By.id(RunCucumberFeatures.locators.getProperty("bankname")));
		for(int i = 0 ; i<banklst.size(); i++) {
			String bnkname = banklst.get(i).getText().trim();
			if(bnkname.equalsIgnoreCase(bankname)) {
				banklst.get(i).click();
				break;
			}
		}
	}

}

