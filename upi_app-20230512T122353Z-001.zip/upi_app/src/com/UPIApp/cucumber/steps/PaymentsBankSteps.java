package com.UPIApp.cucumber.steps;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.UPIApp.TestUtils.DriverManager;
import com.UPIApp.cucumber.tests.RunCucumberFeatures;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class PaymentsBankSteps extends BaseSteps {

    public static String usr_mpin = null;

    @Then("^I should see tabs$")
    public void iShouldSeeTabs() throws Throwable {
        waitForElement(By.id(
                RunCucumberFeatures.locators.getProperty("tabs_navigation")));
    }

    @And("^I should see Payment Bank tab$")
    public void iShouldSeeAPBTab() throws Throwable {

        waitForElement(
                By.id(RunCucumberFeatures.locators.getProperty("bank_tab")));
    }

    @And("^I click on Payment Bank tab$")
    public void iAmAbleToClickPaymentsBank() throws Throwable {
        WebElement tab_paymentbank = DriverManager.getDriver().findElement(
                By.id(RunCucumberFeatures.locators.getProperty("bank_tab")));
        tab_paymentbank.click();

    }

    @And("^I click on BHIM UPI action$")
    public void iClickOnBHIMUPI() throws InterruptedException {
        Thread.sleep(10000);
        System.out.println("search upi");
        // waitForElement(By.xpath(RunCucumberFeatures.locators.getProperty("btn_BHIMUPI")));
        WebElement btn_BHIMUPI = DriverManager.getDriver().findElement(By.xpath(
                RunCucumberFeatures.locators.getProperty("btn_BHIMUPI")));
        System.out.println("click upi");
        btn_BHIMUPI.click();
        Thread.sleep(10000);
    }

    @Then("^I should see Enter mPIN screen$")
    public void iShouldSeeMPINScreen() throws Throwable {
        waitForElement(By
                .xpath(RunCucumberFeatures.locators.getProperty("title_mPIN")));
    }

    @Then("^I should see Change mPIN screen$")
    public void iShouldSeeChangeMPINScreen() throws Throwable {
        // waitForElement(By.xpath(
        // RunCucumberFeatures.locators.getProperty("title_changemPIN")));
        WebElement txt_currentmPIN = DriverManager.getDriver().findElement(
                By.id(RunCucumberFeatures.locators.getProperty("txt_mPIN")));
        assertEquals(txt_currentmPIN.getText(), "Enter your current mPIN");
    }

    @Then("^I should see New mPIN screen$")
    public void iShouldSeeNewMPINScreen() throws Throwable {
        WebElement txt_currentmPIN = DriverManager.getDriver().findElement(
                By.id(RunCucumberFeatures.locators.getProperty("txt_mPIN")));
        assertEquals(txt_currentmPIN.getText(), "Enter your new mPIN");
    }

    @Then("^I should see Re-enter mPIN screen$")
    public void iShouldSeeReenterMPINScreen() throws Throwable {
        WebElement txt_currentmPIN = DriverManager.getDriver().findElement(
                By.id(RunCucumberFeatures.locators.getProperty("txt_mPIN")));
        assertEquals(txt_currentmPIN.getText(), "Re-enter your new mPIN");
    }

    @And("^I fill logged-in user mPIN$")
    public void iAmAbleToFillmPIN() {

        String usr_type = configProperty.getProperty("upi_registration_type");
        if (usr_type.equalsIgnoreCase("SBA")) {
            usr_mpin = configProperty.getProperty("upi_SBA_mobnum_mpin");
        } else {
            usr_mpin = configProperty.getProperty("upi_LKY_mobnum_mpin");
        }
        System.out.println(usr_mpin);
        fillKeypadValue(usr_mpin);
    }

    @And("^I enter user current mPIN$")
    public void iAmAbleToEntermPIN() {

        String usr_type = configProperty.getProperty("upi_registration_type");
        if (usr_type.equalsIgnoreCase("SBA")) {
            usr_mpin = configProperty.getProperty("upi_SBA_mobnum_mpin");
        } else {
            usr_mpin = configProperty.getProperty("upi_LKY_mobnum_mpin");
        }

        fillKeypadValue(usr_mpin);
    }

    @And("^I enter user new mPIN$")
    public void iAmAbleToEnterNewmPIN() throws InterruptedException {

        String usr_type = configProperty.getProperty("upi_registration_type");
        if (usr_type.equalsIgnoreCase("SBA")) {
            usr_mpin = configProperty.getProperty("upi_SBA_mobnum_new_mpin");
        } else {
            usr_mpin = configProperty.getProperty("upi_LKY_mobnum_new_mpin");
        }

        fillKeypadValue(usr_mpin);

    }

    @Then("^I should see BHIM UPI icon$")
    public void iShouldSeeBHIMUPIIcon() throws Throwable {
        WebElement userType = DriverManager.getDriver().findElement(
                By.id(RunCucumberFeatures.locators.getProperty("usrtype")));
        waitForElement(
                By.id(RunCucumberFeatures.locators.getProperty("usrtype")));
        Assert.assertEquals(userType.getText(), "Savings A/c");
        WebElement btn_BHIMUPI = DriverManager.getDriver().findElement(By.xpath(
                RunCucumberFeatures.locators.getProperty("btn_BHIMUPI")));
        assertTrue(btn_BHIMUPI.isDisplayed());
    }

    @And("^I click on Done button$")
    public void iClickOnDoneButton() throws Throwable {
        WebElement txn_date = DriverManager.getDriver().findElement(
                By.id(RunCucumberFeatures.locators.getProperty("btn_done")));
        txn_date.click();

    }

}
