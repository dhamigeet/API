package com.UPIApp.cucumber.steps;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;

import com.UPIApp.TestUtils.DriverManager;
import com.UPIApp.cucumber.tests.RunCucumberFeatures;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class LoginSteps extends BaseSteps {

    public static String mobnum = null;
    public static String custID = null;
    public int port = 4723;

    @Before
    public void setupLoginSteps() throws IOException {
        /*
         * if(!checkIfServerIsRunnning(port)) {
         * System.out.println("Starting the Appium Server.."); startServer(); }
         * else { System.out.println("Appium Server already running on Port - "
         * + port); }
         */
        System.out.println("Initializing the driver..");
        initializeTheDriver();

    }

    @Then("^I should see Home tabs$")
    public void iShouldSeeTabs() throws Throwable {
        waitForElement(
                By.id(RunCucumberFeatures.locators.getProperty("home_tab")));
    }

    @Given("^I am on App Home screen$")
    public void iAmOnAppHomeScreen() throws Throwable {
        WebElement UPI_Uri = DriverManager.getDriver().findElement(
                By.id(RunCucumberFeatures.locators.getProperty("UPI_Uri")));
        UPI_Uri.clear();
        UPI_Uri.sendKeys(configProperty.getProperty("UPI_deep_lnk"));
        WebElement btn_goToUri = DriverManager.getDriver().findElement(
                By.id(RunCucumberFeatures.locators.getProperty("btn_goToUri")));
        btn_goToUri.click();
        // waitForElement(By
        // .id(RunCucumberFeatures.locators.getProperty("btn_continue")));
    }

    @And("^I click on Continue button$")
    public void iAmAbleToClickContinue() throws Throwable {
        mobnum = fetchAccounttype(mobnum);
        WebElement btn_continue = DriverManager.getDriver().findElement(By
                .id(RunCucumberFeatures.locators.getProperty("btn_continue")));
        btn_continue.click();
        Thread.sleep(2000);
    }

    @And("^I click on Request OTP button$")
    public void iAmAbleToClickRequestOTP() throws Throwable {

        WebElement btn_reqotp = DriverManager.getDriver().findElement(
                By.id(RunCucumberFeatures.locators.getProperty("btn_reqotp")));
        btn_reqotp.click();

    }

    @And("^I login with mobile number$")
    public void iAmAbleToLogin() throws Exception {

        String usr_type = configProperty.getProperty("upi_registration_type");
        if (usr_type.equalsIgnoreCase("SBA")) {
            mobnum = configProperty.getProperty("upi_SBA_mobnum");
        } else {
            mobnum = configProperty.getProperty("upi_LKY_mobnum");
        }

        waitForElement(By.id(RunCucumberFeatures.locators
                .getProperty("txtbox_mobilenumber_login")));
        System.out.println("I login with mobile number");
        WebElement txtbox_mobilenumber_login = DriverManager.getDriver()
                .findElement(By.id(RunCucumberFeatures.locators
                        .getProperty("txtbox_mobilenumber_login")));
        txtbox_mobilenumber_login.clear();
        System.out.println("I login with mobile number");

        System.out.println("I login with mobile number---1");
        WebElement lnk_autoNumberList = DriverManager.getDriver()
                .findElement(By.id(RunCucumberFeatures.locators
                        .getProperty("lnk_autoNumberList")));
        lnk_autoNumberList.click();
        System.out.println("I login with mobile number---1");
        // txtbox_mobilenumber_login.click();
        txtbox_mobilenumber_login.sendKeys(mobnum);
        /*
         * String querystr =
         * "select CUSTOMER_ID from UPI_CUSTOMER where MOBILE_NUMBER = '" +
         * mobnum + "' and ACTOR_STATUS = 'ACTIVE'"; custID =
         * DBConnection.getValueFromDB( configProperty.getProperty("dburl"),
         * configProperty.getProperty("dbusrname"),
         * configProperty.getProperty("dbusrpwd"), querystr);
         */
    }

    @Then("^I should see OTP Verification screen$")
    public void iShouldSeeOTPVerificationScreen() throws Throwable {
        waitForElement(By.xpath(
                RunCucumberFeatures.locators.getProperty("title_otpscreen")));
        waitForElement(
                By.id(RunCucumberFeatures.locators.getProperty("box_otp")));
        Thread.sleep(50000);

    }

    @Then("^I click on skip option$")
    public void iClickOnSkipOption() throws Throwable {
        Thread.sleep(2000);
        waitForElement(
                By.id(RunCucumberFeatures.locators.getProperty("btn_done1")));
        WebElement btn_done1 = DriverManager.getDriver().findElement(
                By.id(RunCucumberFeatures.locators.getProperty("btn_done1")));
        /*
         * waitForElement(By.id(
         * RunCucumberFeatures.locators.getProperty("btn_skipOption")));
         * WebElement btn_skip = DriverManager.getDriver().findElement(By.id(
         * RunCucumberFeatures.locators.getProperty("btn_skipOption")));
         */
        btn_done1.click();
        Thread.sleep(2000);
    }

    @After
    public void teardown(Scenario scenario) {
        if (scenario.isFailed()) {
            // Take a screenshot...
            final byte[] screenshot = ((TakesScreenshot) DriverManager
                    .getDriver()).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshot, "image/png"); // ... and embed it in the
                                                     // report.
        }

        System.out.println("test teardown!");
        System.out.println("Closing driver!");
        teardownTheDriver();

        /*
         * System.out.println("Stopping Appium Server!"); stopServer();
         */

    }
}
