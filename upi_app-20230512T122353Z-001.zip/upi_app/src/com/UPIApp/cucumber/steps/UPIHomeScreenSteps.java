package com.UPIApp.cucumber.steps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import io.appium.java_client.TouchAction;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.UPIApp.TestUtils.DBConnection;
import com.UPIApp.TestUtils.DriverManager;
import com.UPIApp.cucumber.tests.RunCucumberFeatures;

public class UPIHomeScreenSteps extends BaseSteps {
	
	public static String primaryvpatitle = null;
	
    @Then("^I should see UPI screen$")
    public void iShouldSeeUPIScreen() throws Throwable {
    	waitForElement(By.xpath(RunCucumberFeatures.locators.getProperty("title_bhimupi")));
    	WebElement bhimupititle = DriverManager.getDriver().findElement(By.xpath(RunCucumberFeatures.locators.getProperty("title_bhimupi")));
    	assertTrue(bhimupititle.isDisplayed());
    }
    
    @Then("^I navigate to UPI screen$")
    public void iNavigateToUPIScreen() throws Throwable {
        WebElement backNavigation = DriverManager.getDriver().findElement(By.xpath(RunCucumberFeatures.locators.getProperty("link_back")));
        backNavigation.click();
      }
    
	@Then("^I should see Pay Money in Quick Actions on UPI Home Screen$")
    public void iShouldSeePayMoney() throws Throwable {
		waitForElement(By.xpath(RunCucumberFeatures.locators.getProperty("txt_paymoney")));
		WebElement paymoneytitle = DriverManager.getDriver().findElement(By.xpath(RunCucumberFeatures.locators.getProperty("txt_paymoney")));
		assertTrue(paymoneytitle.isDisplayed());
    }
	
	@Then("^I should see Request Money in Quick Actions on UPI Home Screen$")
    public void iShouldSeeRequestMoney() throws Throwable {
    	waitForElement(By.xpath(RunCucumberFeatures.locators.getProperty("txt_requestmoney")));
    	WebElement requestmoneytitle = DriverManager.getDriver().findElement(By.xpath(RunCucumberFeatures.locators.getProperty("txt_requestmoney")));
    	assertTrue(requestmoneytitle.isDisplayed());
    }
    
    @And("^I click on Request Money tab$")
    public void iAmAbleToClickRequestMoney() throws Throwable {
    	WebElement txt_requestmoney = DriverManager.getDriver().findElement(By.xpath(RunCucumberFeatures.locators.getProperty("txt_requestmoney")));
    	txt_requestmoney.click();
    }
	
	@And("^I click on Pay Money tab$")
	public void iAmAbleToClickPayMoney() throws Throwable {
		WebElement txt_paymoney = DriverManager.getDriver().findElement(By.xpath(RunCucumberFeatures.locators.getProperty("txt_paymoney")));
		txt_paymoney.click();
	}
	
	@Then("^I should see Primary VPA$")
    public void iShouldSeePrimaryVPABox() throws Throwable {
		waitForElement(By.id(RunCucumberFeatures.locators.getProperty("primaryvpabox")));
		WebElement primaryvpabox = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("primaryvpabox")));
		assertTrue(primaryvpabox.isDisplayed());		
    }
	
	@And("^I click on Primary VPA$")
	public void iAmAbleToClickPrimaryVPA() throws Throwable {
		WebElement primaryvpabox = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("primaryvpabox")));
		primaryvpabox.click();
				
	}
	
	@And("^I click on Pending Transactions$")
	public void iAmAbleToClickPendingTxns() throws Throwable {
		waitForElement(By.xpath(RunCucumberFeatures.locators.getProperty("txns")));
		WebElement txnsbox = DriverManager.getDriver().findElement(By.xpath(RunCucumberFeatures.locators.getProperty("txns")));
		assertTrue(txnsbox.isDisplayed());
		
		WebElement lnk_pendingtxns = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_pendingtxns")));
		lnk_pendingtxns.click();
				
	}
	
	@And("^I click on More Transactions$")
	public void iAmAbleToClickMoreTxns() throws Throwable {
		waitForElement(By.xpath(RunCucumberFeatures.locators.getProperty("txns")));
		WebElement txnsbox = DriverManager.getDriver().findElement(By.xpath(RunCucumberFeatures.locators.getProperty("txns")));
		assertTrue(txnsbox.isDisplayed());
		
		WebElement lnk_moretxns = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_moretxns")));
		lnk_moretxns.click();
				
	}
	
	@Then("^I should see screen with title \"([^\"]*)\"$")
    public void iShouldSeeScreen(String title) throws Throwable {
		waitForElement(By.id(RunCucumberFeatures.locators.getProperty("screenheader")));
		WebElement screenheader = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("screenheader")));
		String screentitle = screenheader.findElement(By.className(RunCucumberFeatures.locators.getProperty("screentitle"))).getText().trim();
		assertEquals(screentitle, title);
    }
	
	@Then("^I should see Primary VPA Screen$")
    public void iShouldSeePrimaryVPAScreen() throws Throwable {
		waitForElement(By.id(RunCucumberFeatures.locators.getProperty("screenheader")));
		WebElement screenheader = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("screenheader")));
		String screentitle = screenheader.findElement(By.className(RunCucumberFeatures.locators.getProperty("screentitle"))).getText().trim();
		assertEquals(screentitle, primaryvpatitle);
    }
	
	@Then("^I should see Pay Money Screen$")
    public void iShouldSeePayMoneyScreen() throws Throwable {
		waitForElement(By.xpath(RunCucumberFeatures.locators.getProperty("txt_paymoney")));
		WebElement paymoneytitle = DriverManager.getDriver().findElement(By.xpath(RunCucumberFeatures.locators.getProperty("txt_paymoney")));
		assertTrue(paymoneytitle.isDisplayed());
    }
	
	@Then("^I should see Primary VPA Title$")
    public void iShouldSeePrimaryVPA() throws Throwable {
		
		String primaryvpa_dbquery = "select VPA from UPI_VPA where CUSTOMER_ID = '"+ LoginSteps.custID +"' and IS_PRIMARY = '1' and STATUS = 'ACTIVE'";
		String primaryvpa_db = DBConnection.getValueFromDB(configProperty.getProperty("dburl"), configProperty.getProperty("dbusrname"), configProperty.getProperty("dbusrpwd"), primaryvpa_dbquery);
		
		WebElement primaryvpabox = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("primaryvpabox")));
		primaryvpatitle = primaryvpabox.findElement(By.id(RunCucumberFeatures.locators.getProperty("txt_VPAtitle"))).getText().trim();	
		
		assertEquals(primaryvpatitle, primaryvpa_db);
    }
	
	@And("^I click on More VPAs link$")
    public void iClickOnMoreVPAs() {
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_moreVPAs")));
    	WebElement lnk_moreVPAs = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_moreVPAs")));
    	lnk_moreVPAs.click();
    }
	
	
	
	@Then("^I should see Deregister UPI$")
    public void iAmAbleToClickUPIOptions() {
		
		WebElement lnk_MoreOptions= DriverManager.getDriver().findElement(By.xpath(RunCucumberFeatures.locators.getProperty("lnk_moreoptions")));
		lnk_MoreOptions.click();
    }
	
	@And("^I click on Deregister UPI$")
    public void iClickOnDeregisterUPI() {
    	waitForElement(By.xpath(RunCucumberFeatures.locators.getProperty("lnk_deregisterUPI")));
    	WebElement lnk_deregisterUPI = DriverManager.getDriver().findElement(By.xpath(RunCucumberFeatures.locators.getProperty("lnk_deregisterUPI")));
    	lnk_deregisterUPI.click();
    }
	
	@Then("^I should see no title popup with \"([^\"]*)\" and click OK for confirmation$")
    public void iShouldSeePopUpMsg_NoTitle(String msg) throws Throwable {
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("dialogmsg")));
    	
    	WebElement confirmpopup = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("dialogmsg")));
    	assertTrue(confirmpopup.isDisplayed());
    	
    	String ui_msg = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("dialogmsg"))).getText().trim();
   		assertEquals(ui_msg, msg);
   		
   		WebElement btn_dialogOK = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("btn_dialogOK")));
   		btn_dialogOK.click();
    }
	
	@Then("^I should see \"([^\"]*)\" and click OK for confirmation$")
    public void iShouldSeeDeregisterTxt(String msg) throws Throwable {
    	waitForElement(By.xpath(RunCucumberFeatures.locators.getProperty("txt_deregister")));
    	
    	WebElement confirmpopup = DriverManager.getDriver().findElement(By.xpath(RunCucumberFeatures.locators.getProperty("txt_deregister")));
    	assertTrue(confirmpopup.isDisplayed());
    	
    	String ui_msg = DriverManager.getDriver().findElement(By.xpath(RunCucumberFeatures.locators.getProperty("txt_deregister"))).getText().trim();
   		assertEquals(ui_msg, msg);
   		
   		WebElement btn_dialogOK = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("btn_dialogOK")));
   		btn_dialogOK.click();
    }
	
	@Then("^I should see collect money request in transactions with vpa and amount \"([^\"]*)\" with status \"([^\"]*)\"$")
    public void iShouldSeeTxnUPIHomeScreen(String reqamt, String reqstatus) throws Throwable {
	/*	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("recenttxnbox")));
		
    	//code for refresh the screen by swipe top to bottom
		WebElement bottomElement = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_moretxns")));
    	WebElement topElement = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_pendingtxns")));
    	
    	TouchAction action = new TouchAction(DriverManager.getDriver()); 
    	action.longPress(topElement).moveTo(bottomElement).release().perform();
    	
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("recenttxnbox")));
    	
    	WebElement recenttxnbox = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("recenttxnbox")));
		    	
		String reqmoneytimestamp = recenttxnbox.findElement(By.id(RunCucumberFeatures.locators.getProperty("txt_timestamp"))).getText().trim();
    	assertEquals(reqmoneytimestamp, AmountSteps.reqmoneydate);
    	
		String reqmoney = recenttxnbox.findElement(By.id(RunCucumberFeatures.locators.getProperty("txt_requestmoneyamt"))).getText().trim();	
		reqmoney = reqmoney.substring(2, 4);
    	assertEquals(reqmoney, reqamt);
    	
		String reqmoneystatus = recenttxnbox.findElement(By.id(RunCucumberFeatures.locators.getProperty("txt_requestmoneystatus"))).getText().trim();
    	assertEquals(reqmoneystatus, reqstatus); */
    }
	
	@Then("^I should see Transactions with atmost 3 txns$")
    public void iShouldSeeTxnsBox() {
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("txn_box")));
    	WebElement txn_box = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txn_box")));
    	
    	List <WebElement> alltxns = txn_box.findElements(By.id(RunCucumberFeatures.locators.getProperty("lst_txns")));
    	assertTrue(alltxns.size() <= 3);
    }
	
	
	
    
}

