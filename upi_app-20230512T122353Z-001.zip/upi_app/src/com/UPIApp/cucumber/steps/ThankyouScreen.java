package com.UPIApp.cucumber.steps;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.UPIApp.TestUtils.DriverManager;
import com.UPIApp.cucumber.tests.RunCucumberFeatures;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class ThankyouScreen extends BaseSteps {

    @Then("^I should see Thankyou screen$")
    public void iShouldSeeThankyouScreen() throws Throwable {
        Thread.sleep(2000);
        waitForElement(By.xpath(
                RunCucumberFeatures.locators.getProperty("title_Thankyou")));
        WebElement amountscreentitle = DriverManager.getDriver()
                .findElement(By.xpath(RunCucumberFeatures.locators
                        .getProperty("title_Thankyou")));
        assertTrue(amountscreentitle.isDisplayed());
    }

    @And("^I verify Successful Transaction status$")
    public void verifySuccessfulTransactionStatus() throws Throwable {
        Thread.sleep(6000);
        WebElement thankyou_txn_status = DriverManager.getDriver().findElement(
                By.id(RunCucumberFeatures.locators.getProperty("txn_status")));
        assertTrue(thankyou_txn_status.getText().equals("Payment Successful"));

    }

    @And("^Verify Failure Transaction status$")
    public void verifyFailureTransactionStatus(String status) throws Throwable {
        Thread.sleep(10000);
        WebElement thankyou_txn_status = DriverManager.getDriver().findElement(
                By.id(RunCucumberFeatures.locators.getProperty("txn_status")));
        assertTrue(thankyou_txn_status.getText().equals(status));

    }

    @And("^I verify Transaction Id$")
    public void verifyTransactionId() throws Throwable {
        WebElement txn_Id = DriverManager.getDriver().findElement(
                By.id(RunCucumberFeatures.locators.getProperty("txnId_Key")));
        assertTrue(txn_Id.getText().equals("Transaction ID"));
    }

    @And("^I verify transacted \"([^\"]*)\"$")
    public void verifyTransactedAmount(String amt) throws Throwable {
        WebElement amount = DriverManager.getDriver().findElement(
                By.id(RunCucumberFeatures.locators.getProperty("amount_key")));
        assertTrue(amount.getText().equals("Amount"));
    }

    @And("^I verify Beneficiary \"([^\"]*)\"$")
    public void verifyBeneVPA(String vpa1) throws Throwable {
        WebElement vpa = DriverManager.getDriver().findElement(By.xpath(
                RunCucumberFeatures.locators.getProperty("bene_vpa_key")));
        assertTrue(vpa.getText().equals("Bene VPA"));
    }

    @And("^I verify Transaction Date$")
    public void verifyTransactionDate() throws Throwable {
        WebElement txn_date = DriverManager.getDriver().findElement(By.xpath(
                RunCucumberFeatures.locators.getProperty("txn_date_key")));
        assertTrue(txn_date.getText().equals("Transaction Date"));
    }

}
