package com.UPIApp.cucumber.steps;

import static org.testng.Assert.assertTrue;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.UPIApp.TestUtils.DriverManager;
import com.UPIApp.cucumber.tests.RunCucumberFeatures;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class UPIRegistrationSteps extends BaseSteps {

    @Then("^I should see UPI Welcome screen$")
    public void iShouldSeeUPIWelcomeScreen() throws Throwable {
        waitForElement(
                By.id(RunCucumberFeatures.locators.getProperty("txt_welcome")));
        WebElement welcomescreenbox = DriverManager.getDriver().findElement(
                By.id(RunCucumberFeatures.locators.getProperty("txt_welcome")));
        assertTrue(welcomescreenbox.isDisplayed());
    }

    @Then("^I should see Get Started button$")
    public void iShouldSeeGetStarted() throws Throwable {
        waitForElement(By.xpath(
                RunCucumberFeatures.locators.getProperty("btn_getstarted")));
        WebElement startedbutton = DriverManager.getDriver()
                .findElement(By.xpath(RunCucumberFeatures.locators
                        .getProperty("btn_getstarted")));
        assertTrue(startedbutton.isDisplayed());
    }

    @And("^I click on Get Started button$")
    public void iAmAbleToClickGetStarted() throws Throwable {

        waitForElement(By.xpath(
                RunCucumberFeatures.locators.getProperty("btn_getstarted")));
        WebElement btn_getstarted = DriverManager.getDriver()
                .findElement(By.xpath(RunCucumberFeatures.locators
                        .getProperty("btn_getstarted")));
        btn_getstarted.click();

    }

    @And("^I click Send SMS button$")
    public void iAmAbleToClickSendSMS() throws Throwable {
     //   Thread.sleep(2000);
        waitForElement(By.id(RunCucumberFeatures.locators.getProperty("btn_sendSMS")));
        WebElement btn_sendSMS = DriverManager.getDriver().findElement(
                By.id(RunCucumberFeatures.locators.getProperty("btn_sendSMS")));
        btn_sendSMS.click();
        // WebElement btn_sentSMSOK =
        // DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("btn_sentsmsOK")));
        // btn_sentSMSOK.click();
      //  Thread.sleep(5000);
    }

    @And("^I click Done button on Congrats screen$")
    public void iAmAbleToClickDone() throws Throwable {
        waitForElement(
                By.id(RunCucumberFeatures.locators.getProperty("btn_done")));
        WebElement btn_done = DriverManager.getDriver().findElement(
                By.id(RunCucumberFeatures.locators.getProperty("btn_done")));
        btn_done.click();
        Thread.sleep(3000);
    }

    @And("^I click on OK button for confirming the SMS sent on device$")
    public void iAmAbleToClickSMSOK() throws Throwable {
        Thread.sleep(2000);
        WebElement btn_sentsmsOK = DriverManager.getDriver().findElement(By
                .id(RunCucumberFeatures.locators.getProperty("btn_sentsmsOK")));
        btn_sentsmsOK.click();
    }

    @Then("^I should see SMS sent on the device$")
    public void iShouldSeeSMSSentFlow() throws Throwable {
        try {

            waitForElement(By.id(
                    RunCucumberFeatures.locators.getProperty("title_dualsim")));
            WebElement dualsimtitle = DriverManager.getDriver()
                    .findElement(By.id(RunCucumberFeatures.locators
                            .getProperty("title_dualsim")));
            if (dualsimtitle.isDisplayed()) {
                WebElement sim1img = DriverManager.getDriver()
                        .findElement(By.id(RunCucumberFeatures.locators
                                .getProperty("img_sim1")));
                assertTrue(sim1img.isDisplayed());
                WebElement sim2img = DriverManager.getDriver()
                        .findElement(By.id(RunCucumberFeatures.locators
                                .getProperty("img_sim2")));
                assertTrue(sim2img.isDisplayed());
                WebElement cancellink = DriverManager.getDriver()
                        .findElement(By.id(RunCucumberFeatures.locators
                                .getProperty("lnk_cancel")));
                assertTrue(cancellink.isDisplayed());
                WebElement proceedlink = DriverManager.getDriver()
                        .findElement(By.id(RunCucumberFeatures.locators
                                .getProperty("lnk_proceed")));
                assertTrue(proceedlink.isDisplayed());
                proceedlink.click();
                try {
                    if (dualsimtitle.isDisplayed()) {
                        WebElement img_sim2 = DriverManager.getDriver()
                                .findElement(By.id(RunCucumberFeatures.locators
                                        .getProperty("img_sim2")));
                        img_sim2.click();
                        WebElement lnk_proceed = DriverManager.getDriver()
                                .findElement(By.id(RunCucumberFeatures.locators
                                        .getProperty("lnk_proceed")));
                        lnk_proceed.click();
                    }
                } catch (Exception a) {

                }

            }
        } catch (Exception e) {

        }

    }

    @And("^I click on cross icon for exit from UPI Welcome Screen$")
    public void iAmAbleToClickClose() throws Throwable {
        WebElement lnk_cross = DriverManager.getDriver().findElement(
                By.id(RunCucumberFeatures.locators.getProperty("lnk_cross")));
        lnk_cross.click();
    }

    @Then("^I should see UPI Set up Screen with Send SMS button$")
    public void iShouldSeeUPISetupScreen() throws Throwable {
        waitForElement(By.xpath(
                RunCucumberFeatures.locators.getProperty("title_upisetup")));
        WebElement upisetuptitle = DriverManager.getDriver()
                .findElement(By.xpath(RunCucumberFeatures.locators
                        .getProperty("title_upisetup")));
        assertTrue(upisetuptitle.isDisplayed());

        WebElement sendsmsbutton = DriverManager.getDriver().findElement(
                By.id(RunCucumberFeatures.locators.getProperty("btn_sendSMS")));
        assertTrue(sendsmsbutton.isDisplayed());
    }

    @Then("^I should see Congrats Screen$")
    public void iShouldSeeCongratsScreen() throws Throwable {

        waitForElement(By.xpath(
                RunCucumberFeatures.locators.getProperty("title_congrats")));
        WebElement title_congrats = DriverManager.getDriver()
                .findElement(By.xpath(RunCucumberFeatures.locators
                        .getProperty("title_congrats")));
        assertTrue(title_congrats.isDisplayed());

        WebElement txt_requestmoney = DriverManager.getDriver()
                .findElement(By.xpath(RunCucumberFeatures.locators
                        .getProperty("txt_requestmoney")));
        assertTrue(txt_requestmoney.isDisplayed());

        WebElement txt_paymoney = DriverManager.getDriver()
                .findElement(By.xpath(RunCucumberFeatures.locators
                        .getProperty("txt_paymoney")));
        assertTrue(txt_paymoney.isDisplayed());

        WebElement btn_done = DriverManager.getDriver().findElement(
                By.id(RunCucumberFeatures.locators.getProperty("btn_done")));
        assertTrue(btn_done.isDisplayed());

    }

    @And("^I select \"([^\"]*)\" as my bank account for UPI Registration$")
    public void iAmAbleToSelectBank_UPIReg(String bankacc) {
        waitForElement(By.id(
                RunCucumberFeatures.locators.getProperty("upireg_srchbank")));
        selectBank_UPIReg(bankacc);

        waitForElement(By.id(
                RunCucumberFeatures.locators.getProperty("bankaccountspopup")));
        WebElement bankaccountspopup = DriverManager.getDriver()
                .findElement(By.id(RunCucumberFeatures.locators
                        .getProperty("bankaccountspopup")));
        assertTrue(bankaccountspopup.isDisplayed());

        waitForElement(By.id(
                RunCucumberFeatures.locators.getProperty("accountcontainer")));
        WebElement allbankaccountsbox = DriverManager.getDriver()
                .findElement(By.id(RunCucumberFeatures.locators
                        .getProperty("accountcontainer")));
        assertTrue(allbankaccountsbox.isDisplayed());

        // Select bank account
        List<WebElement> bankacclst = allbankaccountsbox.findElements(By
                .id(RunCucumberFeatures.locators.getProperty("accountnumber")));
        bankacclst.get(0).click();

    }

    public static void selectBank_UPIReg(String bankname) {
        DriverManager.getDriver().findElement(By.id(
                RunCucumberFeatures.locators.getProperty("upireg_srchbank")))
                .sendKeys(bankname);
        WebElement banklistcontainer = DriverManager.getDriver()
                .findElement(By.id(RunCucumberFeatures.locators
                        .getProperty("banklistcontainer")));

        List<WebElement> banklst = banklistcontainer.findElements(
                By.id(RunCucumberFeatures.locators.getProperty("bankname")));
        for (int i = 0; i < banklst.size(); i++) {
            String bnkname = banklst.get(i).getText().trim();
            if (bnkname.equalsIgnoreCase(bankname)) {
                banklst.get(i).click();
                break;
            }
        }
    }

}
