package com.UPIApp.cucumber.steps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;
import java.io.IOException;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.UPIApp.TestUtils.DriverManager;
import com.UPIApp.cucumber.tests.RunCucumberFeatures;

public class MoreTxnsSteps extends BaseSteps {
	   
    @Then("^I should see MODIFY link$")
    public void iShouldSeeMODIFYLink() throws Throwable {
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_modify")));
    	WebElement lnk_modify = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_modify")));
    	assertTrue(lnk_modify.isDisplayed());
    }
    
    @And("^I click on MODIFY link$")
    public void iAmAbleToClickMODIFY() throws Throwable {
    	WebElement lnk_modify = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("lnk_modify")));
    	lnk_modify.click();
    }
    
    @And("^I click on Cancel button$")
    public void iAmAbleToClickCancel() throws Throwable {
    	WebElement btn_datefilter_cancel = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("btn_datefilter_cancel")));
    	btn_datefilter_cancel.click();
    }
    
    @And("^I click on BACK button$")
    public void iAmAbleToClickBACKImage() throws Throwable {
    	WebElement screenheader = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("screenheader")));
    	WebElement lnk_back = screenheader.findElement(By.className(RunCucumberFeatures.locators.getProperty("lnk_back")));
    	lnk_back.click();
    }
    
    @And("^I click on Cancel on date picker$")
    public void iAmAbleToClickCANCEL_DatePicker() throws Throwable {
    	WebElement btn_datepicker_CANCEL = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("btn_datepicker_CANCEL")));
    	btn_datepicker_CANCEL.click();
    }
    
    @Then("^I should see \"([^\"]*)\" as date non clickable for year \"([^\"]*)\"$")
    public void iShouldSeeNonClickDate(String date, String year) throws Throwable {
    	WebElement futuredate = null;
    	
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("popup_datepicker")));
    	WebElement datepicker_year = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txt_datepicker_year")));
        String cal_year = datepicker_year.getText().trim();
        
        if(cal_year.equalsIgnoreCase(year)) {
        	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("box_month_dates")));
        	WebElement box_month_dates = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("box_month_dates")));
            
            List<WebElement> alldates = box_month_dates.findElements(By.className(RunCucumberFeatures.locators.getProperty("txt_date_class")));
            for (int i = 0 ; i < alldates.size(); i++) {
                String cal_date = alldates.get(i).getText().trim();
                if(cal_date.equalsIgnoreCase(date)) {
                	futuredate = alldates.get(i);
                	break;
                }
            }
            
            assertTrue(!(futuredate.isEnabled()));
        }
    }
    
    @Then("^I should see Date filter with CANCEL and SEARCH buttons$")
    public void iShouldSeeDateFilterWithButtons() throws IOException {
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("date_filterbox")));
    	WebElement date_filterbox = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("date_filterbox")));
    	assertTrue(date_filterbox.isDisplayed());
    	
    	WebElement btn_datefilter_cancel = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("btn_datefilter_cancel")));
    	assertTrue(btn_datefilter_cancel.isDisplayed());
    	
    	WebElement btn_datefilter_search = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("btn_datefilter_search")));
    	assertTrue(btn_datefilter_search.isDisplayed());
    	
    	WebElement txtbox_fromdate = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_fromdate")));
    	assertTrue(txtbox_fromdate.isDisplayed());
    	
    	WebElement txtbox_todate = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_todate")));
    	assertTrue(txtbox_todate.isDisplayed());
    	
    }
    
    @And("^I click on FROM Date field$")
    public void iAmAbleToClickFROMDate() throws Throwable {
    	WebElement txtbox_fromdate = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_fromdate")));
    	txtbox_fromdate.click();
    }
    
    @And("^I click on TO Date field$")
    public void iAmAbleToClickToDate() throws Throwable {
    	WebElement txtbox_todate = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_todate")));
    	txtbox_todate.click();
    }
    
    @And("^I select Date from the calender with \"([^\"]*)\" and \"([^\"]*)\"$")
    public void iAmAbleToSelectDate(String year, String date) throws Throwable {
    	selectDate(year, date);
    }
    
    @Then("^I should see filled dates \"([^\"]*)\" as FROM date and \"([^\"]*)\" as FROM year with \"([^\"]*)\" as TO date and \"([^\"]*)\" as TO year$")
    public void iShouldSeeDates(String frmdte, String frmyr, String todte, String toyr) throws Throwable {
    	waitForElement(By.xpath(RunCucumberFeatures.locators.getProperty("title_moretxns")));
    	WebElement txtbox_fromdate = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_fromdate")));
    	String fromdate = txtbox_fromdate.getText().trim();
    	
    	String val_fromdate[] = fromdate.split(" ");
    	String startdate = val_fromdate[0];
    	String startyear = val_fromdate[2];
    	
    	assertEquals(startdate, frmdte);
    	assertEquals(startyear, frmyr);
    	
    	WebElement txtbox_todate = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txtbox_todate")));
    	String todate = txtbox_todate.getText().trim();
    	
    	String val_todate[] = todate.split(" ");
    	String enddate = val_todate[0];
    	String endyear = val_todate[2];
    	
    	assertEquals(enddate, todte);
    	assertEquals(endyear, toyr);
    	
    }
    
    @Then("^I should see Txns$")
    public void iShouldSeeTxns() throws Throwable {
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("lst_txns_box")));
    	WebElement lst_txns_box = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("lst_txns_box")));
    	
    	assertTrue(lst_txns_box.isDisplayed());
    }
    
    @Then("^I should see date and time in the txns$")
    public void iShouldSeeDatenTimeInTxns() throws Throwable {
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("lst_txns_box")));
    	WebElement txt_timestamp = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txt_timestamp")));
    	
    	assertTrue(txt_timestamp.isDisplayed());
    }
    
    @Then("^I should see username in the txns$")
    public void iShouldSeeUsernameInTxns() throws Throwable {
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("lst_txns_box")));
    	WebElement txt_requestmoneyvpa = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txt_requestmoneyvpa")));
    	
    	assertTrue(txt_requestmoneyvpa.isDisplayed());
    }
    
    public void selectDate(String yr, String dte) {
    	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("popup_datepicker")));
    	WebElement datepicker_year = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("txt_datepicker_year")));
        String cal_year = datepicker_year.getText().trim();
        
        if(!(cal_year.equalsIgnoreCase(yr))) {
        	datepicker_year.click();
        	waitForElement(By.id(RunCucumberFeatures.locators.getProperty("lst_year")));
            WebElement years_box = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("lst_year")));
            
            List<WebElement> allyears = years_box.findElements(By.id(RunCucumberFeatures.locators.getProperty("txt_year")));
            for (int i = 0 ; i < allyears.size(); i++) {
                   String cal_lst_year = allyears.get(i).getText().trim();
                   if(cal_lst_year.equalsIgnoreCase(yr)) {
                	   allyears.get(i).click();
                	   break;
                   }
            }

        }
        
        waitForElement(By.id(RunCucumberFeatures.locators.getProperty("box_month_dates")));
        WebElement box_month_dates = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("box_month_dates")));
        
        List<WebElement> alldates = box_month_dates.findElements(By.className(RunCucumberFeatures.locators.getProperty("txt_date_class")));
        for (int i = 0 ; i < alldates.size(); i++) {
            String cal_date = alldates.get(i).getText().trim();
            if(cal_date.equalsIgnoreCase(dte)) {
            	alldates.get(i).click();
            	break;
            }
        }
        
        WebElement btn_date_OK = DriverManager.getDriver().findElement(By.id(RunCucumberFeatures.locators.getProperty("btn_datepicker_OK")));
        btn_date_OK.click();
    }
    
}

