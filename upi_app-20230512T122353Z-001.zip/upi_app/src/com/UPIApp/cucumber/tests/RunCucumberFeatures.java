package com.UPIApp.cucumber.tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;

import com.github.mkolisnyk.cucumber.runner.ExtendedCucumberOptions;
import com.github.mkolisnyk.cucumber.runner.ExtendedTestNGRunner;

import cucumber.api.CucumberOptions;

@ExtendedCucumberOptions(
        jsonReport = "src/results/cucumber-reports/cucumber.json",
        retryCount = 3, detailedReport = true, overviewReport = true,
        knownErrorsReport = true, detailedAggregatedReport = true,
        jsonUsageReport = "src/results/cucumber-reports/cucumber-usage.json",
        usageReport = true, toPDF = true,
        knownErrorsConfig = "src/com/UPIApp/resources/known-errors-source/sample_model.json",
        outputFolder = "src/results")
@CucumberOptions(
        plugin = { "pretty",
                "html:src/results/cucumber-reports/cucumber-html-report",
                "json:src/results/cucumber-reports/cucumber.json",
                "usage:src/results/cucumber-reports/cucumber-usage.json",
                "junit:src/results/cucumber-reports/cucumber-results.xml" },
        features = { "src/com/UPIApp/cucumber/feature" },
        glue = { "com.UPIApp.cucumber.steps" }, tags = { "@UPIRegistration, @UPIPayMoney" })

public class RunCucumberFeatures extends ExtendedTestNGRunner {

    public static Properties locators;

    @Parameters({ "appmode" })
    @BeforeSuite
    public void beforeSuite(String appmode) {

        try {
            if (appmode.equalsIgnoreCase("debug")) {
                FileInputStream debugOR = new FileInputStream(new File(System
                        .getProperty("user.dir")
                        + "//src//com//UPIApp//resources//debugOR.properties"));
                locators = new Properties();
                try {
                    locators.load(debugOR);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else if (appmode.equalsIgnoreCase("preprod")) {
                FileInputStream preprodOR = new FileInputStream(new File(System
                        .getProperty("user.dir")
                        + "//src//com//UPIApp//resources//PreprodOR.properties"));
                locators = new Properties();
                try {
                    locators.load(preprodOR);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }

}
