$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Sanity.feature");
formatter.feature({
  "line": 2,
  "name": "UPI Inhouse Sanity Test Suite",
  "description": "",
  "id": "upi-inhouse-sanity-test-suite",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@UPI"
    },
    {
      "line": 1,
      "name": "@UPIvishal"
    }
  ]
});
